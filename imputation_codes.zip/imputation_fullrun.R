rm(list=ls())
require(parallel)
require(profvis)
setwd("~/codes/stratos_tg2_4/phase2_run/")
source("imputation_main_function.R")
`%,%` <- function(x,y) paste0(x,y)

X = as.list(data.frame(t(expand.grid(1:5, 1:15))))
mclapply(X,
         imputation_run,
         mc.preschedule = TRUE,
         mc.set.seed = TRUE,
         mc.silent = FALSE,
         mc.cores = 10,
         mc.cleanup = TRUE,
         mc.allow.recursive = TRUE)
