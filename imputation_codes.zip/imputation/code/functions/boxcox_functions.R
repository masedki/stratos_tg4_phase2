# Functions used for Box-Cox survey
# Includes functions to initialize the Box-Cox function,
# find the best lambda, transform the variables, and Winsorization

#Extracts original scale variable, covariate data, and subject weighting from input data
initialize_boxcox <- function(input.data,
                              variable.to.transform,
                              covariate.list,
                              weight.variable,
                              id.var,
                              repeat.obs.var) {
  
  #convert input data to data frame for consistent processing
  input.frame <- as.data.frame(input.data)
  
  #extract variable to be transformed
  original.variable <- input.frame[,variable.to.transform,drop=TRUE]
  
  #extract covariate data
  if(!is.null(covariate.list) && length(covariate.list) > 0) {
    
    covariate.data <- input.frame[,covariate.list,drop=FALSE]
  } else {
    
    covariate.data <- NULL
  }
  
  #extract weight variable and its decimal precision if it is given
  if(!is.null(weight.variable)) {
    
    subject.weighting <- input.frame[,weight.variable,drop=TRUE]
  } else {
    
    subject.weighting <- rep(1, nrow(input.frame))
  }
  
  #extract subject ID if it is given
  if(!is.null(id.var)) {
    
    subject.id <- input.frame[,id.var,drop=FALSE]
  } else {
    
    subject.id <- NULL
  }
  
  #extract admin ID if it is given
  if(!is.null(repeat.obs.var)) {
    
    admin.id <- input.frame[,repeat.obs.var,drop=FALSE]
  } else {
    
    admin.id <- NULL
  }
  
  #return parameters in list
  boxcox.parameters <- list(original.variable=original.variable,
                            covariate.data=covariate.data,
                            subject.weighting=subject.weighting,
                            subject.id=subject.id,
                            admin.id=admin.id)
}



#Finds the lambda value that corresponds to the Box-Cox transformation that most resembles a normal distribution
boxcox_survey_loop <- function(original.variable,
                               lambda.start,
                               lambda.increment,
                               num.lambdas,
                               covariate.data,
                               subject.weighting) {

  #list of lambdas to check
  lambda.list <- seq(from=lambda.start, by=lambda.increment, length.out=num.lambdas)
  
  #calculate 1st to 99th percentiles of Box-Cox transformed variable for each lambda
  lambda.percentiles <- vapply(lambda.list, function(lambda) calculate_percentiles(lambda, original.variable, covariate.data, subject.weighting), numeric(99))
  
  #calculate SSE of each lambda's percentiles against the standard normal distribution
  lambda.sse <- calculate_sse(lambda.percentiles)
  
  #find the lambda that corresponds to the minimum SSE
  min.sse.index <- which.min(lambda.sse)
  best.lambda <- lambda.list[min.sse.index]
  
  return(best.lambda)
}



#Calculates the 1st to 99th percentiles of a Box-Cox transformed variable using a given lambda value
calculate_percentiles <- function(lambda,
                                  original.variable,
                                  covariate.data,
                                  subject.weighting) {

  #calculate Box-Cox transformation of the original variable
  if(lambda == 0) {
    
    box.cox.variable <- log(original.variable)
  } else {
    
    box.cox.variable <- (original.variable^lambda - 1)/lambda
  }

  #calculate percentiles of Box-Cox transformed variable
  if(is.null(covariate.data)) {

    #if no covariates are given, calculate percentiles directly
    box.cox.percentiles <- weighted_quantiles(box.cox.variable, subject.weighting, seq(0.01,0.99,0.01))
  } else {
    
    #fit model using Box-Cox transformed variable vs covariates and calculate residuals
    model.data <- data.frame(box.cox=box.cox.variable, covariate.data, subject.weighting=subject.weighting)
    covariate.formula <- paste(names(covariate.data), collapse="+")
    model.formula <- paste0("box.cox ~ ", covariate.formula)
    box.cox.model <- lm(model.formula, model.data, weights=subject.weighting)
    box.cox.residuals <- box.cox.model$residuals
    
    #calculate percentiles from residuals
    box.cox.percentiles <- weighted_quantiles(box.cox.residuals, subject.weighting, seq(0.01,0.99,0.01))
  }
  
  return(box.cox.percentiles)
}



#Calculates the sum of square errors (SSE) of Box-Cox transformations using different lambda values compared to normal distribution
calculate_sse <- function(lambda.percentiles) {

  #calculate percentiles of the standard normal distribution
  normal.percentiles <- qnorm(seq(0.01,0.99,0.01))
  
  #calculate sum of squared devations for normal distribution (mean is known to be zero)
  sum.square.normal <- sum(normal.percentiles^2)
  
  #calculate means of percentiles for each lambda
  lambda.percentile.means <- colMeans(lambda.percentiles)
  
  #calculate deviations of each lambda's percentiles
  lambda.percentile.deviation <- t(t(lambda.percentiles) - lambda.percentile.means)
  
  #calculate sum of squared deviations for each lambda's percentiles
  sum.square.lambda <- colSums(lambda.percentile.deviation^2)
  
  #calculate cross products of normal deviations and lambda deviations
  sum.cross.normal.lambda <- colSums(lambda.percentile.deviation*normal.percentiles)
  
  #calculate sum of square errors (SSE) for each lambda
  lambda.sse <- sum.square.normal - ((sum.cross.normal.lambda^2)/sum.square.lambda)
  
  return(lambda.sse)
}



#Performs a Box-Cox transformation on a variable using the best lambda value selected by Box-Cox survey
transform_and_winsorize <- function(original.variable,
                                    survey.lambda,
                                    winsorize,
                                    covariate.data,
                                    subject.weighting,
                                    interquartile.range.multiple,
                                    subject.id,
                                    admin.id) {

  #Apply Box-Cox transformation to chosen variable with selected lambda
  if(survey.lambda == 0) {
    
    box.cox.variable <- log(original.variable)
  } else {
    
    box.cox.variable <- (original.variable^survey.lambda - 1)/survey.lambda
  }
  
  if(winsorize) {
    
    winsorization.data <- winsorize(box.cox.variable=box.cox.variable,
                                                            covariate.data=covariate.data,
                                                            subject.weighting=subject.weighting,
                                                            interquartile.range.multiple=interquartile.range.multiple)
    
    influential.observations <- winsorization.data[winsorization.data$outlier.direction != 0,]
    
    boxcox.winsorization <- influential.observations[,c("boxcox.winsorized.low", "boxcox.winsorized.high", "boxcox.winsorized.values")]
    if(survey.lambda == 0) {
      
      original.scale.winsorization <- exp(boxcox.winsorization)
    } else {
      
      original.scale.winsorization <- (survey.lambda*boxcox.winsorization + 1)^(1/survey.lambda)
    }
    names(original.scale.winsorization) <- c("original.winsorized.low", "original.winsorized.high", "original.winsorized.values")
    
    suggested.winsorization.report <- data.frame(original.variable=original.variable[winsorization.data$outlier.direction != 0],
                                                 original.scale.winsorization,
                                                 boxcox.variable=box.cox.variable[winsorization.data$outlier.direction != 0],
                                                 boxcox.winsorization)
  } else {
    
    suggested.winsorization.report <- NULL
  }
  
  return(suggested.winsorization.report)
}



#Winsorizes extreme values in a Box-Cox transformed variable
winsorize <- function(box.cox.variable,
                      covariate.data,
                      subject.weighting,
                      interquartile.range.multiple) {

    #calculate 25th and 75th percentile of variable
    percentile25 <- weighted_quantiles(box.cox.variable, subject.weighting, 0.25)
    percentile75 <- weighted_quantiles(box.cox.variable, subject.weighting, 0.75)
    
    #calculate low and high thresholds for Winsorization
    interquartile.range <- percentile75 - percentile25
    low.threshold <- percentile25 - interquartile.range.multiple*interquartile.range
    high.threshold <- percentile75 + interquartile.range.multiple*interquartile.range
    
    #calculate suggested Winsorized Box-Cox variable
    if(is.null(covariate.data)) {
      
      #if there are no covariates, determine outliers by the magnitude of each observation
      high.outliers <- box.cox.variable > high.threshold
      low.outliers <- box.cox.variable < low.threshold
      regular.values <- !(high.outliers | low.outliers)
      
      outlier.direction <- high.outliers - low.outliers
      winsorized.value.high <- high.threshold
      winsorized.value.low <- low.threshold
      
    } else {
      
      #if covariates are given, fit a model of the Box-Cox variable vs covariates and find the predicted values
      model.data <- data.frame(box.cox=box.cox.variable, covariate.data, subject.weighting=subject.weighting)
      covariate.formula <- paste(names(covariate.data), collapse="+")
      model.formula <- paste0("box.cox ~ ", covariate.formula)
      box.cox.model <- lm(model.formula, model.data, weights=subject.weighting)
      box.cox.predictions <- predict(box.cox.model)
      
      #calculate residuals from predictions
      box.cox.residuals <- box.cox.variable - box.cox.predictions
      
      #find outliers using the magnitude of the residuals
      high.outliers <- box.cox.residuals > high.threshold
      low.outliers <- box.cox.residuals < low.threshold
      regular.values <- !(high.outliers | low.outliers)
      
      outlier.direction <- high.outliers - low.outliers
      winsorized.value.high <- high.threshold + box.cox.predictions
      winsorized.value.low <- low.threshold + box.cox.predictions
    }
    
    winsorized.boxcox.values <- high.outliers*winsorized.value.high + low.outliers*winsorized.value.low + regular.values*box.cox.variable
    
    #output winsorized Box-Cox variable and threshold values
    winsorization.data <- data.frame(outlier.direction=outlier.direction,
                                     boxcox.winsorized.low=winsorized.value.low,
                                     boxcox.winsorized.high=winsorized.value.high,
                                     boxcox.winsorized.values=winsorized.boxcox.values)
    return(winsorization.data)
}