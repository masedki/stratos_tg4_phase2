# Name: Amer Moosa
# 
# Program Purpose:
# Impute true X using measurement error model parameters

impute_true_x <- function(boxcox.X1,
                          subject.id,
                          covariate.matrix,
                          sigma.e,
                          sigma.u,
                          beta,
                          lambda,
                          minimum.amount,
                          num.sims,
                          random.normals=NULL) {

  #derive parameters for imputation
  r.squared <- sigma.u/(sigma.u + sigma.e)
  std.dev.r <- sqrt(sigma.u*(1 - r.squared))
  num.subjects <- length(boxcox.X1)
  
  #impute true X values
  Xbeta <- covariate.matrix %*% beta
  boxcox.x.imputed.mean <- Xbeta + r.squared*(as.matrix(boxcox.X1) - Xbeta)
  
  distrib.reps <- list()
  for(replicate in seq_len(num.sims)) {
    
    if(is.null(random.normals)) {
      
      normal.matrix <- matrix(rnorm(num.subjects), nrow=num.subjects, ncol=1)
    } else {
      
      normal.matrix <- random.normals[num.subjects*(replicate-1) + seq_len(num.subjects),]
    }
    boxcox.X.imputed <- boxcox.x.imputed.mean + std.dev.r*normal.matrix
    
    backtransformation.data <- data.frame(tran_center=0, tran_scale=1, tran_lambda=lambda, minamount=minimum.amount)
    x.imputed <- backtransform(backtransformation.data=backtransformation.data,
                               xbeta.u.var=as.matrix(boxcox.X.imputed),
                               sigma.e.var=sigma.e)
    
    distrib.reps[[replicate]] <- data.frame(replicate=replicate, subject.id=subject.id, x.imputed=x.imputed, ux.norm=as.vector(normal.matrix), bc.t=as.vector(boxcox.X.imputed), pred.t=as.vector(boxcox.x.imputed.mean))
  }
  distrib.data <- do.call(rbind, distrib.reps)
  
  return(distrib.data)
}

backtransform <- function(backtransformation.data,
                          xbeta.u.var,
                          sigma.e.var) {
  
  #sample size of XBeta + U
  sample.size <- nrow(xbeta.u.var)
  
  #back-transformation variables
  lambda <- backtransformation.data[,"tran_lambda",drop=TRUE]
  center <- backtransformation.data[,"tran_center",drop=TRUE]
  scale <- backtransformation.data[,"tran_scale",drop=TRUE]
  minimum.amount <- backtransformation.data[,"minamount",drop=TRUE]
  
  #values for 9-point approximation
  x.9pt.approx <- c(-2.1, -1.3, -0.8, -0.5, 0, 0.5, 0.8, 1.3, 2.1)
  w.9pt.approx.given <- c(0.063345, 0.080255, 0.070458, 0.159698, 0.252489, 0.159698, 0.070458, 0.080255, 0.063345)
  w.9pt.approx <- w.9pt.approx.given/sum(w.9pt.approx.given)
  
  if(lambda == 0) {
    
    #perform exact back-transformation if lambda is zero
    positive.amounts <- exp(center + (scale*xbeta.u.var + ((scale^2)*sigma.e.var/2)))
    
    backtransformed.amounts <- pmax(positive.amounts, minimum.amount)
  } else {
    
    #perform 9-point approximation for non-zero lambda
    box.cox.9pt.approx <- vapply(x.9pt.approx, function(x) center + scale*(xbeta.u.var + x*sqrt(sigma.e.var)), numeric(sample.size))
    inverse.box.cox.9pt.approx <- apply(box.cox.9pt.approx, 2, function(bc) inverse_box_cox(bc, lambda, minimum.amount))
    
    backtransformed.amounts <- inverse.box.cox.9pt.approx %*% w.9pt.approx
  }
  
  return(backtransformed.amounts)
}



inverse_box_cox <- function(box.cox.vector, lambda, minimum.amount) {
  
  if(lambda == 0) {
    
    positive.inverse.box.cox <- exp(box.cox.vector)
  } else{
    
    positive.inverse.box.cox <- pmax(1 + lambda*box.cox.vector, 0)^(1/lambda)
  }
  
  inverse.box.cox <- pmax(positive.inverse.box.cox, minimum.amount)
  
  return(inverse.box.cox)
}