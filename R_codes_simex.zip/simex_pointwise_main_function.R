#############################################################################
######  THIS CODE CONTAINS A FUNCTION THAT EXECUTES POINTWISE SIMEX    ######
######  TO CORRECT FOR MEASUREMENT ERROR (ME) IN NON-LINEAR FUNCTIONS  ######
######        AND RETURNS ESTIMATES OF THE CORRECTED NL FUNCTION       ###### 
######        FOR SELECTED X VALUES, IN A TABLE WITH TWO COLUMNS       ######
######                       ENTITLED "x" AND "fx"                     ###### 
######                                                                 ######
######     THIS CODE IS SPECIFIC TO DATASETS 1-5 PROVIDED IN THE       ######
######  PRELIMINARY ANALYSIS PHASE OF THE SIMEX TG2-TG4 COLLABORATION  ######
#############################################################################

##################################################
######  CREATED BY: STEVE FERREIRA GUERRA   ######
######     LAST MODIFIED: NOV 11, 2023      ######
##################################################
simex_pointwise_run = function(p){
  
  dataset = p[1]
  comb = p[2]
  #Relative Paths for source files
  data.directory   <- "../datasets_phase2/"
  output.directory <- "./results_simex_pointwise/"
  seeds = read.table("seeds")  
  
  dataset_main <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 1 %,% "/comb_" %,% comb, header=TRUE, sep="")
  dataset_val <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 2 %,% "/comb_" %,% comb, header=TRUE, sep="")
  
  
  
  
  
  n = dim(dataset_main)[1]
  
  #x-values for reporting
  if (dataset==1) {x.pred <- seq(from=10,to=50,by=0.2)}
  if (dataset==2) {x.pred <- seq(from=2.6, to=4, by=0.007)}
  if (dataset==3) {x.pred <- seq(from=45, to=155, by=0.55)}
  if (dataset==4) {x.pred <- seq(from=40, to=160, by=0.6)}
  if (dataset==5) {x.pred <- seq(from=18, to=92, by=0.37)}
  
  
  #Obtaining an estimate of sd of ME from the validation data
  sd_ME <- sqrt(var(dataset_val$xrep1 - dataset_val$xrep2)/2)
  
  ### SIMEX ALGORITHM ###
  
  #Objects to store final SIMEX-corrected values for each x value
  SIMEX.est_reg.bs = c()
  SIMEX.est_p.spli = c()
  SIMEX.est_fp = c()
  
  #Increments for increase of ME
  lambda = seq(0,2,0.2)
  #Number of SIMEX repetitions
  B = 25
  
  #To store predicted f(x) values for Extrapolation
  pred_reg.bs_mean <- matrix(NA, nrow = length(lambda), ncol = length(x.pred))
  pred_p.spli_mean <- matrix(NA, nrow = length(lambda), ncol = length(x.pred))
  pred_fp_mean <- matrix(NA, nrow = length(lambda), ncol = length(x.pred))
  
  for (j in c(1:length(lambda))) {
    #Intermediate objects to store values for each SIMEX repetition
    pred_reg.bs <- matrix(NA, nrow = B, ncol = length(x.pred))
    pred_p.spli <- matrix(NA, nrow = B, ncol = length(x.pred))
    pred_fp <- matrix(NA, nrow = B, ncol = length(x.pred))
    
    for (b in c(1:B)) {
      set.seed(seeds[b,1])
      
      #Increasing ME
      X.star.star = dataset_main$xselobs1 + sqrt(lambda[j])*rnorm(n,0,sd_ME)
      
      #Cubic B-splines estimate
      pred_reg.bs[b,] <- predict(glm(dataset_main$ysel ~ bs(X.star.star, degree=3, knots = c(median(dataset_main$xselobs1)), Boundary.knots = range(dataset_main$xselobs1)), family = "binomial"),
                                 type = "link", newdata = data.frame(X.star.star = x.pred))
      
      #P-Splines
      pred_p.spli[b,] <- predict(gam(dataset_main$ysel ~ s(X.star.star, bs="ps", k = 14), family = "binomial", method = "REML"),
                                 type = "link", newdata = data.frame(X.star.star = x.pred))
      
      #Fractional polynomials
      pred_fp[b,] <- predict(mfp(dataset_main$ysel ~ fp(X.star.star, select = 1, alpha = 1), family = "binomial"),
                             type = "link", newdata = data.frame(X.star.star = x.pred))
      
    }
    pred_reg.bs_mean[j,] <- colMeans(pred_reg.bs)
    pred_p.spli_mean[j,] <- colMeans(pred_p.spli)
    pred_fp_mean[j,] <- colMeans(pred_fp)
  }
  
  #### EXTRAPOLATION PHASE ####
  
  for (k in c(1:length(x.pred))){
    
    #Using a quadratic extrapolation function
    SIMEX.est_reg.bs[k] <- coef(lm(pred_reg.bs_mean[,k] ~ lambda + I(lambda^2)))%*%c(1,-1,1)
    SIMEX.est_p.spli[k] <- coef(lm(pred_p.spli_mean[,k] ~ lambda + I(lambda^2)))%*%c(1,-1,1)
    SIMEX.est_fp[k] <- coef(lm(pred_fp_mean[,k] ~ lambda + I(lambda^2)))%*%c(1,-1,1)
    
  }
  
  #Outputs three tables for each dataset, where each table contains, the name of the method and the number of the initial dataset
  regbs_SIMEX = data.frame(x=x.pred, fx=SIMEX.est_reg.bs)
  pspli_SIMEX = data.frame(x = x.pred, fx=SIMEX.est_p.spli)
  fp_SIMEX = data.frame(x = x.pred, fx=SIMEX.est_fp)
  save(regbs_SIMEX, pspli_SIMEX, fp_SIMEX, file =  output.directory %,% "res_dataset" %,%  dataset %,% "/res_" %,% "comb_" %,%  comb %,% ".rda")
  gc()
  
}