rm(list=ls())
require(parallel)
setwd("~/codes/stratos_tg2_4/STRATOS_smooth_ME/")
source("skwn_bspline_function.R")
X = as.list(data.frame(t(expand.grid(1:5, 1:15))))

mclapply(X, skwn_bspline_run, mc.preschedule = TRUE, mc.set.seed = TRUE, mc.silent = FALSE, mc.cores = 75,mc.cleanup = TRUE, mc.allow.recursive = TRUE)
