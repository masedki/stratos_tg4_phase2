rm(list=ls())
setwd("~/codes/stratos_tg2_4/STRATOS_smooth_ME/")

imputation_run = function(p){
  
  dataset = p[1]
  comb = p[2]
  #Relative Paths for source files
  data.directory   <- "../datasets_phase2/"
  output.directory <- "./results_imputation/"
  function.directory  <- "./imputation/code/functions/"
  #--------------------------------------------------- Define Functions -------------------------------------------------
  #libraries for measurement error model
  require(lme4)
  
  #libraries for main prediction functions
  require(splines)
  require(mgcv)
  #paste function
  #Box-Cox survey functions
  source(function.directory %,% "boxcox_survey.R")
  source(function.directory %,% "boxcox_functions.R")
  source(function.directory %,% "weighted_quantiles.R")
  #true X imputation
  source(function.directory %,% "impute_true_x.R")
  #calculate measurement error model parameter variances (for multiple imputation)
  source(function.directory %,% "parameter_variances.R")
  #Imputation method functions
  source(function.directory %,% "imputation_methods.R")
  #Spline and fractional polynomial fitting functions
  source(function.directory %,% "model_fitting.R")
  #Spline basis value prediction
  source(function.directory %,% "predict_spline_basis.R")
  #main prediction and data processing functions
  source(function.directory %,% "utility_functions.R")
  
  #--------------------------------------------------------- Main Loop --------------------------------------------------
  #set seed for reproducible results
  set.seed(9999)
  
  x.to.predict =  cbind.data.frame(seq(from=10,to=50,by=0.2), 
                                   seq(from=2.6, to=4, by=0.007), 
                                   seq(from=45, to=155, by=0.55), 
                                   seq(from=40, to=160, by=0.6),
                                   seq(from=18, to=92, by=0.37))
  
  print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... start ... ", sep=""))
  
  #import main and val datasets
  main.dataset <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 1 %,% "/comb_" %,% comb, header=TRUE, sep="")
  val.dataset <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 2 %,% "/comb_" %,% comb, header=TRUE, sep="")
  dataset.predictions <- run_predictions(main=main.dataset, val=val.dataset, x.to.predict=x.to.predict[,dataset])
  
  
  
  
  #------------------------------------------------------- Save Predictions ---------------------------------------------
  #extract predictions from prediction objects
  #regression.calibration <- lapply(dataset.predictions, function(dataset.prediction) dataset.prediction$regression.calibration)
  #multiple.imputation <- lapply(dataset.predictions, function(dataset.prediction) dataset.prediction$multiple.imputation)
  
  regression.calibration <-  dataset.predictions$regression.calibration
  multiple.imputation <- dataset.predictions$multiple.imputation
  
  
  rc.predictions <- regression.calibration$predictions
  mi.predictions <- multiple.imputation$predictions
  
  #Output B-splines, p-splines, and fractional polynomial predictions
  step.num <- seq_len(nrow(x.to.predict))
  output.names <- c("Step #", "Dataset" %,% " Prediction ", "Dataset" %,% " X-value")
  
  for(model in c("bspline", "pspline_reml", "fractional_polynomial")) {
    
    #regression calibration
    rc.prediction <- rc.predictions[[model]]
    rc.prediction.output <- data.frame(step.num, rc.prediction, x.to.predict[,dataset])
    names(rc.prediction.output) <- output.names
    #write.csv(rc.prediction.output, output.directory %,% "regression_calibration_" %,% model %,% ".csv", row.names=FALSE)
    
    #multiple imputation
    mi.prediction <- mi.predictions[[model]]
    mi.prediction.output <- data.frame(step.num, mi.prediction, x.to.predict[,dataset])
    names(mi.prediction.output) <- output.names
    
    save(rc.prediction.output, mi.prediction.output, file =  output.directory %,% "res_dataset" %,%  dataset %,% "/mi_rc_" %,% model %,% "_comb_" %,%  comb %,% ".rda")
    #write.csv(mi.prediction.output, output.directory %,% "multiple_imputation_" %,% model %,% ".csv", row.names=FALSE)
  }
  save(regression.calibration, multiple.imputation, file = output.directory %,% "res_dataset" %,%  dataset %,% "/mi_rc_full_comb_" %,%  comb %,% ".rda")
  print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... ok ... ", sep=""))
  gc() 
  
}

