skwn_fp_run = function(p){
  
  dataset = p[1]
  comb = p[2]
  print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... start ... ", sep=""))
  datapath = "~/codes/stratos_tg2_4/datasets_phase2/dataset"
  resultpath = "~/codes/stratos_tg2_4/STRATOS_smooth_ME/results_skwn_fp/"
  dt.mn <- read.delim(paste(datapath, dataset,"/part_1/comb_", comb,sep=""), header=T, sep="")
  names(dt.mn)[[1]] <- "index"
  dt.rp <- read.delim(paste(datapath, dataset,"/part_2/comb_", comb,sep=""), header=T, sep="")
  ## Some reshaping
  xstr.main <- dt.mn[,"xselobs1"][-dt.rp[,"index2"]]
  xstr.rep1 <- dt.rp[,"xrep1"]
  xstr.rep2 <- dt.rp[,"xrep2"]
  y.main <- dt.mn[,"ysel"][-dt.rp[,"index2"]]
  y.rep <- dt.mn[,"ysel"][dt.rp[,"index2"]]
  
  
  
  
  knt <- quantile(c(xstr.main,xstr.rep1),c(.2,.5,.8))
  mcmc.inputs <- list(n_main=length(xstr.main), n_rep=length(y.rep), knt=knt,  
                      xstr_main=xstr.main, xstr_rep1=xstr.rep1, xstr_rep2=xstr.rep2, 
                      y_main=y.main, y_rep=y.rep)
  
  y.hat <- mean(c(y.main,y.rep))
  tau.hat <- sqrt(var(xstr.rep1-xstr.rep2)/2)
  mu.hat <- mean(xstr.main)
  sig.hat <- sqrt(var(xstr.main)-tau.hat^2)
  xmain.hat <- (xstr.main/tau.hat^2 + mu.hat/sig.hat^2)/(1/tau.hat^2+1/sig.hat^2)
  xrep.hat <-  ((xstr.rep1+xstr.rep2)/tau.hat^2 + mu.hat/sig.hat^2)/(2/tau.hat^2+1/sig.hat^2)
  
  logit <- function(p) {log(p)-log(1-p)}
  
  sval1=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(3, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             unf=runif(2),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## fresh randomize
  sval2=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(3, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             unf=runif(2),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  sval3=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(3, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             unf=runif(2),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  sval4=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(3, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             unf=runif(2),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  
  require(rstan)
  REDO <- T
  flnm <- paste(resultpath, "res_dataset",dataset, "/res_comb_",comb,".rda",sep="")
  
  
  if (REDO) {
    require("rstan")
    rstan_options(auto_write = TRUE)
    
    st.tm <- Sys.time()  
    
    fit <- stan(file = 'code-review-skwn-fp.stan', 
                pars=c("mu","sig","tau","fval","pw","shp_x","shp_xstr",
                       "x_main_head","x_rep_head","link_main_head","link_rep_head"),      
                data = mcmc.inputs, 
                chains=4,
                init=list(sval1,sval2,sval3,sval4), 
                warmup=250, iter=2750, thin=1,cores=1)
    
    lpsd.tm <- Sys.time()-st.tm
    print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... ok ... ", sep=""))
    save(fit, file=flnm)
  }
}