rm(list=ls())
setwd("~/codes/stratos_tg2_4/phase2_run/")
require(parallel)
require(rje)
source("skwn_pspline_function.R")

#toto = skwn_pspline_run(c(2,3))
X = as.list(data.frame(t(expand.grid(1:5, 1:15)))) ## tous les fichiers
Y = X[-c(6,8,9,10,11,12,15,27,29,30,32,33,34,35)] ## on supprime ceux qui ont été déjà calculés
mclapply(Y,
         skwn_pspline_run,
         mc.preschedule = TRUE,
         mc.set.seed = TRUE,
         mc.silent = FALSE,
         mc.cores = 75,
         mc.cleanup = TRUE,
         mc.allow.recursive = TRUE)
