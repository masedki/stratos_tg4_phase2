rm(list=ls())
setwd("~/codes/stratos_tg2_4/phase2_run/")
require(parallel)
require(splines)
require(mgcv)
require(mfp)
#source("simex_pointwise_main_function.R")
source("simex_coef_main_function.R")
`%,%` <- function(x,y) paste0(x,y)

X = as.list(data.frame(t(expand.grid(1:5, 1:15))))
mclapply(X,
         simex_coef_run,
         mc.preschedule = TRUE,
         mc.set.seed = TRUE,
         mc.silent = FALSE,
         mc.cores = 75,
         mc.cleanup = TRUE,
         mc.allow.recursive = TRUE)