# Performs Box-Cox transformation on selected variable using the lambda
# value that gives the most normal distribution.
# 
# Also can perform Winsorization of outlier values in transformed variable
# 
# Process:
# 
# 1. Initialize data needed for Box-Cox survey
# 2. Get best lambda value for chosen variable
# 3. Transform chosen variable using the best lambda
# 4. Output transformed variable and chosen lambda value

boxcox_survey <- function(input.data,
                          variable.to.transform,
                          lambda.start=0,
                          lambda.increment=0.01,
                          num.lambdas=100,
                          covariate.list=NULL,
                          weight.variable=NULL,
                          winsorize=FALSE,
                          interquartile.range.multiple=3,
                          id.var=NULL,
                          repeat.obs.var=NULL) {
  
  #1. Initialize data needed for Box-Cox survey
  boxcox.parameters <- initialize_boxcox(input.data=input.data,
                                         variable.to.transform=variable.to.transform,
                                         covariate.list=covariate.list,
                                         weight.variable=weight.variable,
                                         id.var=id.var,
                                         repeat.obs.var=repeat.obs.var)
  
  #2. Get best lambda value for chosen variable
  survey.lambda <- boxcox_survey_loop(original.variable=boxcox.parameters$original.variable,
                                      lambda.start=lambda.start,
                                      lambda.increment=lambda.increment,
                                      num.lambdas=num.lambdas,
                                      covariate.data=boxcox.parameters$covariate.data,
                                      subject.weighting=boxcox.parameters$subject.weighting)
  
  #3. Generate report of suggested winsorization values
  winsorization.report <- transform_and_winsorize(original.variable=boxcox.parameters$original.variable,
                                                  survey.lambda=survey.lambda,
                                                  winsorize=winsorize,
                                                  covariate.data=boxcox.parameters$covariate.data,
                                                  subject.weighting=boxcox.parameters$subject.weighting,
                                                  interquartile.range.multiple=interquartile.range.multiple,
                                                  subject.id=boxcox.parameters$subject.id)
  
  #4. Output transformed variable and chosen lambda value
  boxcox.output <- list(winsorization.report=winsorization.report,
                        lambda=survey.lambda)
}