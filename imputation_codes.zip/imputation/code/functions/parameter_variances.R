# Name: Amer Moosa
# 
# Program Purpose:
# Calculate beta, Sigma-e, and Sigma-u parameter variances from REML fit with a single random effect
# Uses the expected Fisher information matrix
# Used to generate different parameter values for Multiple Imputation
# Code adapted from 'merDeriv' package (https://cran.r-project.org/web/packages/merDeriv/index.html) and
# 'lmeInfo' package (https://cran.r-project.org/web/packages/lmeInfo/index.html)

parameter_variances <- function(model.fit) {
  
  model.components <- getME(model.fit, "ALL")
  
  #variance matrix calculation
  Zlambda <- model.components$Z %*% t(model.components$Lambdat)
  V.matrix <- (Zlambda %*% t(Zlambda) + Diagonal(model.components$n, 1))*(model.components$sigma)^2
  Vinverse <- solve(V.matrix)
  Vinverse.X <- t(model.components$X) %*% Vinverse
  M.matrix <- solve(Vinverse.X %*% model.components$X)
  
  #derivative calculation
  num.random.effects <- length(model.components$theta)
  lambda.ind <- model.components$Lambda
  lambda.ind@x[] <- model.components$Lind
  V.deriv <- vector("list", (num.random.effects + 1))
  Lambda.deriv <- vector("list", num.random.effects)
  for (i in 1:num.random.effects) {
    Lambda.deriv[[i]] <- forceSymmetric(lambda.ind==i, uplo = "L")
    V.deriv[[i]] <- model.components$Z %*% Lambda.deriv[[i]] %*% t(model.components$Z)
  }
  V.deriv[[num.random.effects+1]] <- Diagonal(nrow(model.components$X), 1)
  
  #Beta variance/covariance
  information.fixed <- t(model.components$X) %*% Vinverse %*% model.components$X
  beta.variance <- solve(information.fixed)
  
  #Sigma variance/covariance
  #broken down this way to avoid large n x n matrix multiplications
  Vinverse.X.M <- t(Vinverse.X) %*% M.matrix
  Vinverse.Vderiv <- lapply(V.deriv, function(dV) Vinverse %*% dV)
  X.Vinverse.Vderiv <- lapply(Vinverse.Vderiv, function(Vinv.dV) t(model.components$X) %*% Vinv.dV)
  Vinverse.Vderiv.Vinverse.X.M <- lapply(Vinverse.Vderiv, function(Vinv.dV) Vinv.dV %*% Vinverse.X.M)
  Binverse.deriv.B <- lapply(X.Vinverse.Vderiv, function(Xt.Vinv.dV) Xt.Vinv.dV %*% Vinverse.X.M)
  
  variance.entries <- matrix(rep(1:(num.random.effects+1)), nrow=num.random.effects+1, ncol=2)
  covariance.entries <- t(combn((num.random.effects+1), 2))
  all.matrix.entries <- rbind(variance.entries, covariance.entries)
  all.matrix.entries <- all.matrix.entries[order(all.matrix.entries[,1], all.matrix.entries[,2]),]
  
  information.random <-  matrix(nrow = (num.random.effects + 1), ncol = (num.random.effects + 1))
  information.random[lower.tri(information.random, diag = TRUE)] <- apply(all.matrix.entries, 1, function(x) {
    
    #first term gives variance estimate for ML, second and third terms account for REML estimation
    product.trace <- sum(t(Vinverse.Vderiv[[x[1]]])*Vinverse.Vderiv[[x[2]]]) -
                     2*sum(t(X.Vinverse.Vderiv[[x[1]]])*Vinverse.Vderiv.Vinverse.X.M[[x[2]]]) +
                     sum(t(Binverse.deriv.B[[x[1]]])*Binverse.deriv.B[[x[2]]])
    as.numeric((1/2)*product.trace)
  })
  sigma.variance <- solve(forceSymmetric(information.random, uplo="L"))
  
  parameter.variances <- list(beta=beta.variance,
                              sigma=sigma.variance)
  
  return(parameter.variances)
}