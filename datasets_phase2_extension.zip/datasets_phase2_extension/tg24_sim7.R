tg24.sim7 = function(nsim,distind,mux,sigx,f,nstudy,vratio,errdist,nrep,filename1,filename2,filename3)
{
  # nsim= number of simulated datapoints
  # distind = indicator for distribution: normal (=0), lognormal (=1), uniform (=2)    
  # mux, sigx = mean and SD of ln(x) for lognormal, or of x for normal, or = lower and upper limits for uniform
  # f is the function that describes the relation between logit(p(y=1)) and x
  # nstudy = number of observations in the main study
  # vratio = error variance divided by variance of X
  # errdist = distribution of error: 0 = normal with mean 0; 1 = gamma with shape parameter 3    
  # nrep = number of repeated observations of x
  # filename1 = text name of output file with main data
  # filename2 = text name of output file with validation data
  # filename3 = text name of output file for Aris    
  
  # generate nsim values of x and y    
  lx<-rnorm(nsim,mux,sigx)
  if (distind==1) x<-exp(lx) 
  if (distind==0) x<-rnorm(nsim,mux,sigx)
  if (distind==2) x<-runif(nsim,mux,sigx)
  if (distind==1) vx<- exp(2*mux + sigx^2)*(exp(sigx^2) - 1) 
  if (distind==0) vx<-sigx^2
  if (distind==2) vx<-(sigx-mux)^2/12
  logitp<-f(x)
  #p<-exp(logitp)/(1+exp(logitp))
  p = plogis(logitp)
  y<-rbinom(nsim, 1, p)
  # generate nsim values of observed error-prone x and its repeats
  sigerr <- sqrt(vratio*vx)
  theta <- sigerr/sqrt(3)
  if (errdist==0) {
    xobs1<- x+rnorm(nsim,0,sigerr)
    xobs2<- x+rnorm(nsim,0,sigerr) }
  if (errdist==1) {
    xobs1<- x + rgamma(nsim,3,scale=theta) - 3*theta
    xobs2<- x + rgamma(nsim,3,scale=theta) - 3*theta }
  
  # exclude extreme values of xobs1 (those in the 1% tails)
  q<-quantile(xobs1,c(0.01,0.99))
  xobs1trunc<-xobs1[xobs1>q[1] & xobs1<q[2]]
  xobs2trunc<-xobs2[xobs1>q[1] & xobs1<q[2]]
  xtrunc<-x[xobs1>q[1] & xobs1<q[2]]
  ytrunc<-y[xobs1>q[1] & xobs1<q[2]]
  
  # separate the remaining values into subsets where y=1 and y=0
  xobs1trunc1<-xobs1trunc[ytrunc==1]
  xobs2trunc1<-xobs2trunc[ytrunc==1]
  xtrunc1<-xtrunc[ytrunc==1]
  xobs1trunc0<-xobs1trunc[ytrunc==0]
  xobs2trunc0<-xobs2trunc[ytrunc==0]
  xtrunc0<-xtrunc[ytrunc==0]
  l1<-length(xobs1trunc1)
  l0<-length(xobs1trunc0)
  
  # randomly select nstudy observations: 1 with y=1 for every 4 with y=0
  index1<-sample(1:l1,nstudy/5)
  index0<-sample(1:l0,4*nstudy/5)
  xselobs11<-xobs1trunc1[index1]
  xsel11<-xtrunc1[index1]
  xselobs10<-xobs1trunc0[index0]
  xsel10<-xtrunc0[index0]
  xselobs21<-xobs2trunc1[index1]
  xselobs20<-xobs2trunc0[index0]
  xselobs1<-c(xselobs11,xselobs10)
  xselobs2<-c(xselobs21,xselobs20)
  xsel<-c(xsel11,xsel10)
  ysel<-c(rep(1,nstudy/5),rep(0,4*nstudy/5))
  
  # put into datsel the main study data that will be sent to the teams
  datsel<-cbind(seq(1:nstudy),ysel,xselobs1)
  datsel.aris<-cbind(seq(1:nstudy),ysel,xselobs1,xsel)
  
  # randomly select a validation subset of repeat xobs values 
  index2<-sample(1:nstudy,nrep)
  xrep1<-xselobs1[index2]
  xrep2<-xselobs2[index2]
  
  # put into datrep the pairs of xobs values from the validation
  datrep<-cbind(index2,xrep1,xrep2)
  
  # output the data to be transferred
  write.table(datsel, file = filename1)
  write.table(datrep, file = filename2)
  write.table(datsel.aris, file = filename3)
}