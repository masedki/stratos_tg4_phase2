# Name: Amer Moosa
# 
# Program Purpose:
# Calculates spline basis values for new data values
# If values are outside of boundary knots, basis value is based on linear extrapolation - this can be turned off
# Similar to Predict.matrix() family of functions in 'mgcv' package

predict_spline_basis <- function(x.values,
                                 knots,
                                 degree=3,
                                 intercept=TRUE,
                                 linear.tails=TRUE) {

  if(linear.tails) {

    boundary.knots <- knots[c(1+degree, length(knots)-degree)]
    
    #regular spline basis for values inside boundary knots
    inner.values <- x.values[x.values >= boundary.knots[1] & x.values <= boundary.knots[2]]
    inner.basis <- splineDesign(knots=knots, x=inner.values, ord=degree+1, outer.ok=TRUE)
    
    #basis for tails extrapolated based on derivative at the boundary knots
    boundary.functions <- splineDesign(knots=knots, x=rep(boundary.knots, each=2), ord=degree+1, derivs=c(0,1,0,1), outer.ok=TRUE)
    
    if(any(x.values < boundary.knots[1])) {
      
      left.tail.values <- x.values[x.values < boundary.knots[1]]
      left.tail.function <- boundary.functions[1:2,]
      left.tail.basis <- cbind(1, left.tail.values - boundary.knots[1]) %*% left.tail.function
    } else {
      
      left.tail.basis <- NULL
    }
    
    if(any(x.values > boundary.knots[2])) {
      
      right.tail.values <- x.values[x.values > boundary.knots[2]]
      right.tail.function <- boundary.functions[3:4,]
      right.tail.basis <- cbind(1, right.tail.values - boundary.knots[2]) %*% right.tail.function
    } else {
      
      right.tail.basis <- NULL
    }
    
    predicted.basis <- rbind(left.tail.basis, inner.basis, right.tail.basis)
  } else {
    
    predicted.basis <- splineDesign(knots=knots, x=x.values, ord=degree+1, outer.ok=TRUE)
  }
  
  if(!intercept) {
    predicted.basis <- predicted.basis[,-1]
  }
  
  return(predicted.basis)
}