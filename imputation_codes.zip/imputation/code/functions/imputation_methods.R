# Name: Amer Moosa
# File location: //omni/btp/dcp/analysis/dcpitis/simulations/STRATOS_Competition/main_script/functions/imputation_methods.R
# Date Started: 10/5/2023
# 
# Program Purpose:
# Contains functions for imputation methods used in STRATOS competition
# 1. Regression Calibration
# 2. Multiple Imputation

#1. Regression Calibration
regression_calibration <- function(analysis.data,
                                   x.to.predict,
                                   ...) {

  #sort data by subject ID
  analysis.data <- analysis.data[order(analysis.data$subject.id),]
  
  #get first recall of the val dataset
  first.recall <- analysis.data[analysis.data$recall == 1, ,drop=FALSE]
  
  #percentiles of observed X
  x.star.data <- first.recall[,c("X", "Y")]
  sorted.x.star.data <- x.star.data[order(x.star.data$X),]
  percentiles <- rep(1:100, each=nrow(x.star.data)/100)
  x.star.percentiles <- aggregate(sorted.x.star.data, by=list(percentile=percentiles), mean)
  x.star.percentiles$logit.Y <- log(x.star.percentiles$Y/(1-x.star.percentiles$Y))
  
  #Box-Cox transformation of X* using Box-Cox survey
  lambda <- boxcox_survey(input.data=first.recall, variable.to.transform="X", covariate.list=NULL)$lambda
  analysis.data$boxcox.X <- boxcox_transform(analysis.data$X, lambda)
  
  #get minimum amount from first recall
  minimum.amount <- min(first.recall$X[first.recall$X > 0])/2
  
  #fit measurement error model
  measurement.error.model <- lmer(boxcox.X ~ (1|subject.id), data=analysis.data)
  
  #extract model parameters
  beta <- fixef(measurement.error.model)
  variance.data <- VarCorr(measurement.error.model)
  sigma.u <- attr(variance.data$subject.id, "stddev")^2
  sigma.e <- attr(variance.data, "sc")^2
  
  #impute true X
  covariate.matrix <- matrix(1, nrow=nrow(first.recall), ncol=1)
  boxcox.X1 <- analysis.data$boxcox.X[analysis.data$recall == 1]
  distrib.data <- impute_true_x(boxcox.X1=boxcox.X1,
                                subject.id=first.recall$subject.id,
                                covariate.matrix=covariate.matrix,
                                beta=beta,
                                sigma.u=sigma.u,
                                sigma.e=sigma.e,
                                lambda=lambda,
                                minimum.amount=minimum.amount,
                                num.sims=1000)
  
  #percentiles of imputed true X
  x.imputed <- distrib.data$x.imputed
  subject.id <- distrib.data$subject.id
  mean.x.imputed <- vapply(split(x.imputed, subject.id), mean, numeric(1))
  x.imputed.data <- data.frame(X=mean.x.imputed, Y=first.recall$Y)
  sorted.x.imputed.data <- x.imputed.data[order(x.imputed.data$X),]
  percentiles <- rep(1:100, each=length(mean.x.imputed)/100)
  x.imputed.percentiles <- aggregate(sorted.x.imputed.data, by=list(percentile=percentiles), mean)
  x.imputed.percentiles$logit.Y <- log(x.imputed.percentiles$Y/(1-x.imputed.percentiles$Y))
  
  values.to.predict <- list(new=x.to.predict, 
                            observed=x.star.percentiles$X, 
                            imputed=x.imputed.percentiles$X)
  
  #generate predictions with cubic B-spline
  bspline <- predict_b_spline(x.imputed=x.imputed,
                              subject.id=subject.id,
                              y.observed=first.recall$Y,
                              x.to.predict=values.to.predict,
                              ...)
  
  #generate predictions with cubic p-spline
  pspline.cross.validation <- predict_p_spline(x.imputed=x.imputed,
                                               subject.id=subject.id,
                                               y.observed=first.recall$Y,
                                               x.to.predict=values.to.predict,
                                               method="GCV.Cp",
                                               ...)
  
  pspline.reml.linear <- predict_p_spline(x.imputed=x.imputed,
                                          subject.id=subject.id,
                                          y.observed=first.recall$Y,
                                          x.to.predict=values.to.predict,
                                          method="REML",
                                          ...)
  
  #generate predictions with fractional polynomial
  best.fractional.polynomial <- predict_fractional_polynomial(x.imputed=x.imputed,
                                                              subject.id=subject.id,
                                                              y.observed=first.recall$Y,
                                                              x.to.predict=values.to.predict,
                                                              ...)
  
  #Output predictions from all methods
  all.predictions <- data.frame(bspline$new,
                                best.fractional.polynomial$new,
                                pspline.cross.validation$new,
                                pspline.reml.linear$new)
  names(all.predictions) <- c("bspline", "fractional_polynomial", "pspline_gcv", "pspline_reml")
  
  imputed.x.percentiles <- data.frame(x.imputed.percentiles[,c("X", "logit.Y")],
                                      bspline=bspline$imputed,
                                      fractional_polynomial=best.fractional.polynomial$imputed,
                                      pspline_gcv=pspline.cross.validation$imputed,
                                      pspline_reml=pspline.reml.linear$imputed)
  observed.x.percentiles <- data.frame(x.star.percentiles[,c("X", "logit.Y")],
                                      bspline=bspline$observed,
                                      fractional_polynomial=best.fractional.polynomial$observed,
                                      pspline_gcv=pspline.cross.validation$observed,
                                      pspline_reml=pspline.reml.linear$observed)
  
  #output predictions and distrib range
  prediction.data <- list(predictions=all.predictions,
                          imputed.x.percentiles=imputed.x.percentiles,
                          observed.x.percentiles=observed.x.percentiles,
                          sigma.e=sigma.e,
                          sigma.u=sigma.u)
  
  return(prediction.data)
}

#2. Multiple imputation
#Cases and controls can have different Box-Cox parameters and variances of the error
multiple_imputation <- function(analysis.data,
                                x.to.predict,
                                num.imputations=25) {

  #sort data by subject ID
  analysis.data <- analysis.data[order(analysis.data$subject.id),]
  
  #split data into controls and cases
  control.index <- which(analysis.data$Y == 0)
  control.data <- analysis.data[control.index,]
  
  case.index <- which(analysis.data$Y == 1)
  case.data <- analysis.data[case.index,]
  
  #subset first recalls for controls and cases
  first.recall <- analysis.data[analysis.data$recall == 1,]
  
  first.recall.control.index <- which(first.recall$Y == 0)
  first.recall.controls <- first.recall[first.recall.control.index,]
  
  first.recall.case.index <- which(first.recall$Y == 1)
  first.recall.cases <- first.recall[first.recall.case.index,]
  
  #percentiles of observed X
  x.star.data <- first.recall[,c("X", "Y")]
  sorted.x.star.data <- x.star.data[order(x.star.data$X),]
  percentiles <- rep(1:100, each=nrow(x.star.data)/100)
  x.star.percentiles <- aggregate(sorted.x.star.data, by=list(percentile=percentiles), mean)
  x.star.percentiles$logit.Y <- log(x.star.percentiles$Y/(1-x.star.percentiles$Y))
  
  #Box-Cox transformation of X* for controls and cases
  lambda.controls <- boxcox_survey(input.data=first.recall.controls, variable.to.transform="X", covariate.list="Y")$lambda
  control.data$boxcox.X <- boxcox_transform(control.data$X, lambda.controls)
  
  lambda.cases <- boxcox_survey(input.data=first.recall.cases, variable.to.transform="X", covariate.list="Y")$lambda
  case.data$boxcox.X <- boxcox_transform(case.data$X, lambda.cases)
  
  #find minimum amounts
  minimum.amount.controls <- min(first.recall.controls$X[first.recall.controls$X > 0])/2
  minimum.amount.cases <- min(first.recall.cases$X[first.recall.cases$X > 0])/2
  
  #fit measurement error models
  model.controls <- lmer(boxcox.X ~ (1|subject.id), data=control.data)
  model.cases <- lmer(boxcox.X ~ (1|subject.id), data=case.data)
  
  #extract base model parameters
  beta.mean.controls <- fixef(model.controls)
  variance.controls <- VarCorr(model.controls)
  sigma.u.mean.controls <- attr(variance.controls$subject.id, "stddev")^2
  sigma.e.mean.controls <- attr(variance.controls, "sc")^2
  
  beta.mean.cases <- fixef(model.cases)
  variance.cases <- VarCorr(model.cases)
  sigma.u.mean.cases <- attr(variance.cases$subject.id, "stddev")^2
  sigma.e.mean.cases <- attr(variance.cases, "sc")^2
  
  #calculate parameter variances
  parameter.variances.controls <- parameter_variances(model.controls)
  parameter.variances.cases <- parameter_variances(model.cases)
  
  #generate imputations of beta, sigma-u, and sigma-e
  beta.var.eigen.controls <- eigen(parameter.variances.controls$beta)
  beta.std.dev.controls <- beta.var.eigen.controls$vectors %*% diag(sqrt(beta.var.eigen.controls$values), nrow=length(beta.mean.controls), ncol=length(beta.mean.controls)) %*% t(beta.var.eigen.controls$vectors)
  beta.imputations.controls <- beta.mean.controls + beta.std.dev.controls %*% matrix(rnorm(length(beta.mean.controls)*num.imputations), nrow=length(beta.mean.controls), ncol=num.imputations)
  
  beta.var.eigen.cases <- eigen(parameter.variances.cases$beta)
  beta.std.dev.cases <- beta.var.eigen.cases$vectors %*% diag(sqrt(beta.var.eigen.cases$values), nrow=length(beta.mean.cases), ncol=length(beta.mean.cases)) %*% t(beta.var.eigen.cases$vectors)
  beta.imputations.cases <- beta.mean.cases + beta.std.dev.cases %*% matrix(rnorm(length(beta.mean.cases)*num.imputations), nrow=length(beta.mean.cases), ncol=num.imputations)
  
  sigma.var.eigen.controls <- eigen(parameter.variances.controls$sigma)
  sigma.std.dev.controls <- sigma.var.eigen.controls$vectors %*% diag(sqrt(sigma.var.eigen.controls$values)) %*% t(sigma.var.eigen.controls$vectors)
  sigma.imputations.controls <- c(sigma.u.mean.controls, sigma.e.mean.controls) + sigma.std.dev.controls %*% matrix(rnorm(2*num.imputations), nrow=2, ncol=num.imputations)
  
  sigma.var.eigen.cases <- eigen(parameter.variances.cases$sigma)
  sigma.std.dev.cases <- sigma.var.eigen.cases$vectors %*% diag(sqrt(sigma.var.eigen.cases$values)) %*% t(sigma.var.eigen.cases$vectors)
  sigma.imputations.cases <- c(sigma.u.mean.cases, sigma.e.mean.cases) + sigma.std.dev.cases %*% matrix(rnorm(2*num.imputations), nrow=2, ncol=num.imputations)
  
  #Get predictions for each imputation
  imputations <- list()
  imputed.x.percentiles <- list()
  observed.x.percentiles <- list()
  for(imputation in seq_len(num.imputations)) {

    print(" - Beginning Imputation " %,% imputation)
    
    #extract parameters for imputation
    beta.controls <- beta.imputations.controls[,imputation]
    sigma.u.controls <- sigma.imputations.controls[1,imputation]
    sigma.e.controls <- sigma.imputations.controls[2,imputation]
    
    beta.cases <- beta.imputations.cases[,imputation]
    sigma.u.cases <- sigma.imputations.cases[1,imputation]
    sigma.e.cases <- sigma.imputations.cases[2,imputation]
    
    r.squared.controls <- sigma.u.controls/(sigma.u.controls + sigma.e.controls)
    var.r.controls <- sigma.u.controls*(1 - r.squared.controls)
    std.dev.r.controls <- sqrt(var.r.controls)
    
    r.squared.cases <- sigma.u.cases/(sigma.u.cases + sigma.e.cases)
    var.r.cases <- sigma.u.cases*(1 - r.squared.cases)
    std.dev.r.cases <- sqrt(var.r.cases)
    
    #impute true X values
    covariate.matrix.controls <- matrix(1, nrow=nrow(first.recall.controls), ncol=1)
    boxcox.X1.controls <- control.data$boxcox.X[control.data$recall == 1]
    distrib.data.controls <- impute_true_x(boxcox.X1=boxcox.X1.controls,
                                           subject.id=first.recall.controls$subject.id,
                                           covariate.matrix=covariate.matrix.controls,
                                           beta=beta.controls,
                                           sigma.u=sigma.u.controls,
                                           sigma.e=sigma.e.controls,
                                           lambda=lambda.controls,
                                           minimum.amount=minimum.amount.controls,
                                           num.sims=1)
    
    covariate.matrix.cases <- matrix(1, nrow=nrow(first.recall.cases), ncol=1)
    boxcox.X1.cases <- case.data$boxcox.X[case.data$recall == 1]
    distrib.data.cases <- impute_true_x(boxcox.X1=boxcox.X1.cases,
                                        subject.id=first.recall.cases$subject.id,
                                        covariate.matrix=covariate.matrix.cases,
                                        beta=beta.cases,
                                        sigma.u=sigma.u.cases,
                                        sigma.e=sigma.e.cases,
                                        lambda=lambda.cases,
                                        minimum.amount=minimum.amount.cases,
                                        num.sims=1)
    
    #combine imputed X values for controls and cases
    distrib.data <- rbind(distrib.data.controls, distrib.data.cases)[order(c(first.recall.control.index, first.recall.case.index)),]
    
    #percentiles of imputed true X
    x.imputed <- distrib.data$x.imputed
    subject.id <- distrib.data$subject.id
    x.imputed.data <- data.frame(X=x.imputed, Y=first.recall$Y)
    sorted.x.imputed.data <- x.imputed.data[order(x.imputed.data$X),]
    percentiles <- rep(1:100, each=length(x.imputed)/100)
    x.imputed.percentiles <- aggregate(sorted.x.imputed.data, by=list(percentile=percentiles), mean)
    x.imputed.percentiles$logit.Y <- log(x.imputed.percentiles$Y/(1-x.imputed.percentiles$Y))
    
    values.to.predict <- list(new=x.to.predict, 
                              observed=x.star.percentiles$X, 
                              imputed=x.imputed.percentiles$X)
    
    #generate predictions with cubic B-spline
    bspline <- predict_b_spline(x.imputed=x.imputed,
                                subject.id=subject.id,
                                y.observed=first.recall$Y,
                                x.to.predict=values.to.predict)
    
    #generate predictions with cubic p-spline
    pspline.cross.validation <- predict_p_spline(x.imputed=x.imputed,
                                                 subject.id=subject.id,
                                                 y.observed=first.recall$Y,
                                                 x.to.predict=values.to.predict,
                                                 method="GCV.Cp")
    
    pspline.reml <- predict_p_spline(x.imputed=x.imputed,
                                     subject.id=subject.id,
                                     y.observed=first.recall$Y,
                                     x.to.predict=values.to.predict,
                                     method="REML")
    
    #generate predictions with fractional polynomial
    best.fractional.polynomial <- predict_fractional_polynomial(x.imputed=x.imputed,
                                                                subject.id=subject.id,
                                                                y.observed=first.recall$Y,
                                                                x.to.predict=values.to.predict)
    
    #Save predictions from all methods
    current.imputation.predictions <- data.frame(bspline$new,
                                                 best.fractional.polynomial$new,
                                                 pspline.cross.validation$new,
                                                 pspline.reml$new)
    names(current.imputation.predictions) <- c("bspline", "fractional_polynomial", "pspline_gcv", "pspline_reml")
    
    
    imputations[[imputation]] <- current.imputation.predictions
    imputed.x.percentiles[[imputation]] <- data.frame(x.imputed.percentiles[,c("X", "logit.Y")],
                                                      bspline=bspline$imputed,
                                                      fractional_polynomial=best.fractional.polynomial$imputed,
                                                      pspline_gcv=pspline.cross.validation$imputed,
                                                      pspline_reml=pspline.reml$imputed)
    observed.x.percentiles[[imputation]] <- data.frame(x.star.percentiles[,c("X", "logit.Y")],
                                                       bspline=bspline$observed,
                                                       fractional_polynomial=best.fractional.polynomial$observed,
                                                       pspline_gcv=pspline.cross.validation$observed,
                                                       pspline_reml=pspline.reml$observed)
  }
  
  #average predictions for all imputations
  average.predictions <- Reduce(`+`, imputations)/num.imputations
  
  #save imputations for each method
  bspline.imputations <- vapply(imputations, function(imputation) imputation[,"bspline"], numeric(length(x.to.predict)))
  pspline.cross.validation.imputations <- vapply(imputations, function(imputation) imputation[,"pspline_gcv"], numeric(length(x.to.predict)))
  pspline.reml.imputations <- vapply(imputations, function(imputation) imputation[,"pspline_reml"], numeric(length(x.to.predict)))
  fractional.polynomial.imputations <- vapply(imputations, function(imputation) imputation[,"fractional_polynomial"], numeric(length(x.to.predict)))
  
  all.imputations <- list(bspline.imputations,
                          fractional.polynomial.imputations,
                          pspline.cross.validation.imputations,
                          pspline.reml.imputations)
  names(all.imputations) <- c("bspline", "fractional_polynomial", "pspline_gcv", "pspline_reml")
  
  #calculate average predictions for observed and imputed X percentiles
  average.imputed.x.percentiles <- Reduce(`+`, imputed.x.percentiles)/num.imputations
  average.observed.x.percentiles <- Reduce(`+`, observed.x.percentiles)/num.imputations
  
  #output average predictions and imputations
  prediction.data <- list(predictions=average.predictions,
                          imputations=all.imputations,
                          imputed.x.percentiles=average.imputed.x.percentiles,
                          observed.x.percentiles=average.observed.x.percentiles,
                          sigma.e.controls=sigma.imputations.controls[2,],
                          sigma.e.cases=sigma.imputations.cases[2,],
                          sigma.u.controls=sigma.imputations.controls[1,],
                          sigma.u.cases=sigma.imputations.cases[1,],
                          lambda.controls=lambda.controls,
                          lambda.cases=lambda.cases)
  
  return(prediction.data)
}