skwn_pspline_run = function(p){
  
  dataset = p[1]
  comb = p[2]
  print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... start ... ", sep=""))
  datapath = "~/codes/stratos_tg2_4/datasets_phase2/dataset"
  resultpath = "~/codes/stratos_tg2_4/phase2_run/results_skwn_pspline/"
  
  dt.mn <- read.delim(paste(datapath, dataset,"/part_1/comb_", comb,sep=""), header=T, sep="")
  names(dt.mn)[[1]] <- "index"
  dt.rp <- read.delim(paste(datapath, dataset,"/part_2/comb_", comb,sep=""), header=T, sep="")
  
  ## Some reshaping
  xstr.main <- dt.mn[,"xselobs1"][-dt.rp[,"index2"]]
  xstr.rep1 <- dt.rp[,"xrep1"]
  xstr.rep2 <- dt.rp[,"xrep2"]
  
  y.main <- dt.mn[,"ysel"][-dt.rp[,"index2"]]
  y.rep <- dt.mn[,"ysel"][dt.rp[,"index2"]]
  
  
  ## Using a multiplicative rescaling of (nonnegative) X to have unit mean
  SCL <- sd(c(xstr.main, xstr.rep1, xstr.rep2))
  xstr.main <- xstr.main/SCL
  xstr.rep1 <- xstr.rep1/SCL
  xstr.rep2 <- xstr.rep2/SCL
  
  
  
  ## Preparation to call Stan
  ### 
  knt.lft <-  quantile(c(xstr.main, xstr.rep1),0.025)
  knt.rht <- quantile(c(xstr.main, xstr.rep1),0.975)
  ### Stan model parameterized as f(knt.lft), ... , f(knt.rht), 14 equally-spaced knots
  knt <- seq(from=knt.lft, to=knt.rht, length=14)
  
  
  ### cf =M %*% fval
  M <- solve(cbind(1,knt,knt^2,knt^3, 
                   pmax(knt- knt[3],0)^3,
                   pmax(knt- knt[4],0)^3,
                   pmax(knt- knt[5],0)^3,
                   pmax(knt- knt[6],0)^3,
                   pmax(knt- knt[7],0)^3,
                   pmax(knt- knt[8],0)^3,
                   pmax(knt- knt[9],0)^3,
                   pmax(knt-knt[10],0)^3,
                   pmax(knt-knt[11],0)^3,
                   pmax(knt-knt[12],0)^3 ))
  
  ### prior on fval    covariance hyp.mat1 + smooth.sd * hyp.mat2
  
  hyp.mat1 <- 10*((0:13)%*%t(0:13)/13^2 + (13:0)%*%t(13:0)/13^2)
  
  m <- diag(c(1.25,rep(1.5,10),1.25))
  
  for (i in 1:11) { 
    m[i,i+1] <- -1
    m[i+1,i] <- -1
  }
  
  for (i in 1:10) { 
    m[i,i+2] <- 0.25
    m[i+2,i] <- 0.25
  }
  
  hyp.mat2 <- matrix(0,14,14)
  hyp.mat2[2:13,2:13] <- solve(m)
  
  
  y.hat <- mean(c(y.main,y.rep))
  tau.hat <- sqrt(var(xstr.rep1-xstr.rep2)/2)
  mu.hat <- mean(xstr.main)
  sig.hat <- sqrt(var(xstr.main)-tau.hat^2)
  xmain.hat <- (xstr.main/tau.hat^2 + mu.hat/sig.hat^2)/(1/tau.hat^2+1/sig.hat^2)
  xrep.hat <-  ((xstr.rep1+xstr.rep2)/tau.hat^2 + mu.hat/sig.hat^2)/(2/tau.hat^2+1/sig.hat^2)
  
  logit <- function(p) {log(p)-log(1-p)}
  ## QR decomposition for plug-in design matrix
  x.hat <- c(xmain.hat, xrep.hat)
  for (i in 1:13) {
    
    sz <- sum((x.hat>knt[i])&(x.hat<knt[i+1]))
    
    if (sz < 5) {
      
      x.hat <- c(x.hat, knt[i]+ ((1:(5-sz))/(6-sz))*(knt[i+1]-knt[i]))
      
    }
    
  }
  
  d.hat <- cbind(1,x.hat, x.hat^2, x.hat^3, 
                 pmax(x.hat - knt[3],0)^3,
                 pmax(x.hat - knt[4],0)^3,
                 pmax(x.hat - knt[5],0)^3,
                 pmax(x.hat - knt[6],0)^3,
                 pmax(x.hat - knt[7],0)^3,
                 pmax(x.hat - knt[8],0)^3,
                 pmax(x.hat - knt[9],0)^3,
                 pmax(x.hat - knt[10],0)^3,
                 pmax(x.hat - knt[11],0)^3,
                 pmax(x.hat - knt[12],0)^3 )
  
  ### R.mat <- qr.R(qr(d.hat))/sqrt(dim(d.hat)[1]-1)
  ### Q.mat <- qr.Q(qr(d.hat))*sqrt(dim(d.hat)[1]-1)
  
  R.mat <- qr.R(qr(d.hat))
  Q.mat <- qr.Q(qr(d.hat))
  #print(R.mat)
  #print(Q.mat)
  
  mcmc.inputs <- list(n_main=length(xstr.main), n_rep=length(y.rep), knt_lft=knt.lft, knt_rht=knt.rht,
                      R_inv=solve(R.mat),  RM_inv=solve(R.mat%*%M),
                      hyp_mat1=hyp.mat1, hyp_mat2=hyp.mat2,
                      xstr_main=xstr.main, xstr_rep1=xstr.rep1, xstr_rep2=xstr.rep2, 
                      y_main=y.main, y_rep=y.rep)
  
  sval1=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,f_smoothsd=.2,
             gval=as.vector(R.mat%*%M%*%rnorm(14, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat))))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## same as sval1, but fresh randomize
  sval2=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,f_smoothsd=.2,
             gval=as.vector(R.mat%*%M%*%rnorm(14, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat))))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## fresh randomize
  sval3=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,f_smoothsd=.2,
             gval=as.vector(R.mat%*%M%*%rnorm(14, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat))))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## fresh randomize
  sval4=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,f_smoothsd=.2,
             gval=as.vector(R.mat%*%M%*%rnorm(14, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat))))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  
  
  
  ## Re-run the MCMC or load saved output?
  REDO <- TRUE
  flnm <- paste(resultpath, "res_dataset",dataset, "/res_comb_",comb,".rda",sep="")
  require(rstan)
  rstan_options(auto_write = TRUE)
  
  
  ## Call Stan (or load previous MCMC output)
  if (REDO) {
    st.tm <- Sys.time()  
    
    fit <- stan(file = 'code-review-skwn-Pspline.stan', 
                pars=c("mu","sig","tau","fval","gval","shp_x","shp_xstr","f_smoothsd", "x_main_head","x_rep_head"),
                data = mcmc.inputs, chains=4, 
                init=list(sval1,sval2,sval3,sval4), 
                warmup=250, iter=2750, thin=1,cores=4)
    
    lpsd.tm <- Sys.time()-st.tm
    print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... ok ... ", sep=""))
    save(fit, lpsd.tm, file=flnm)
  }
}

