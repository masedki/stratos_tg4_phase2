# Name: Amer Moosa
# Date Started: 11/3/2023
# 
# Program Purpose:
#   
# Calculates weighted quantiles for the Box-Cox survey function
# Weighted quantiles are calculated using the empirical distribution function with weights,
# averaging at discontinuities.
# This is equivalent to weighted percentiles with PROC UNIVARIATE in SAS.

weighted_quantiles <- function(x, w, probs) {

  x.sorted <- x[order(x)]
  w.sorted <- w[order(x)]
  
  sum.weights <- sum(w.sorted)
  cumulative.weights <- cumsum(w.sorted)
  
  index <- findInterval(probs*sum.weights, cumulative.weights, all.inside=TRUE)
  
  fractional.part <- probs*sum.weights - cumulative.weights[index]
  
  below.interval <- (fractional.part < 0)
  above.interval <- (fractional.part > 0)
  equal.interval <- (fractional.part == 0)
  
  quantile.below.interval <- x.sorted[index]
  quantile.above.interval <- x.sorted[index+1]
  quantile.equal.interval <- (x.sorted[index] + x.sorted[index+1])/2
  
  weighted.quantile <- quantile.below.interval*below.interval + 
                       quantile.above.interval*above.interval + 
                       quantile.equal.interval*equal.interval
  
  return(weighted.quantile)
}