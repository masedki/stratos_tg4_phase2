# Name: Amer Moosa
# File location: //omni/btp/dcp/analysis/dcpitis/simulations/STRATOS_Competition/main_script/utils/model_fitting.R
# Date Started: 10/5/2023
# 
# Program Purpose:
# Model fitting and prediction functions for use in the STRATOS competition
#
# STRATOS Models
# 1. Cubic B-spline
# 2. p-spline with GCV or REML
# 3. 2nd degree fractional polynomial

# --------------------------------------------------- STRATOS Models --------------------------------------------------
#1. Cubic B-spline
predict_b_spline <- function(x.imputed,
                             subject.id,
                             spline.knot.data=NULL,
                             y.observed,
                             x.to.predict) {
  
  #calculate boundary and interior spline knots
  if(is.null(spline.knot.data)) {
    spline.knot.data <- x.imputed
  }
  boundary.knots <- quantile(spline.knot.data, c(0,1))
  interior.knots <- median(spline.knot.data)
  
  #calculate spline basis from t-values
  bspline.basis <- bs(x.imputed, knots=interior.knots, Boundary.knots=boundary.knots, degree=3)
  colnames(bspline.basis) <- "basis" %,% seq_len(ncol(bspline.basis))
  
  #calculate means of basis functions for each real subject
  basis.mean <- aggregate(bspline.basis, by=list(subject.id=subject.id), mean)

  #run logistic regression of Y against mean basis function values
  model.data <- data.frame(basis.mean, Y=y.observed)
  bspline.formula <- as.formula("Y ~ " %,% paste(colnames(bspline.basis), collapse=" + "))
  bspline.model <- glm(formula=bspline.formula, data=model.data, family=binomial(link="logit"))
  
  #predict Y values using logistic model
  y.predicted <- lapply(x.to.predict, function(x.values) {
    bspline.knots <- c(rep(boundary.knots[1], 4), interior.knots, rep(boundary.knots[2], 4))
    predicted.basis <- predict_spline_basis(x.values=x.values, knots=bspline.knots, intercept=FALSE)
    colnames(predicted.basis) <- colnames(bspline.basis)
    predicted.values <- predict(bspline.model, newdata=as.data.frame(predicted.basis), type="link", control=glm.control(epsilon=1e-13))
  })
  
  return(y.predicted)
}


#2. P-spline regression with cross-validation or REML
predict_p_spline <- function(x.imputed,
                             subject.id,
                             spline.knot.data=NULL,
                             y.observed,
                             x.to.predict,
                             method=c("GCV.Cp", "REML")) {

  #compute boundary and interior knots equally spaced in X-value range
  if(is.null(spline.knot.data)) {
    spline.knot.data <- x.imputed
  }
  boundary.knots <- quantile(spline.knot.data, c(0,1))
  knot.interval <- (boundary.knots[2] - boundary.knots[1])/11
  knots <- seq(boundary.knots[1] - 3*knot.interval, boundary.knots[2] + 3*knot.interval, knot.interval)

  #calculate p-spline basis from t-values
  p.spline.basis.values <- splineDesign(knots=knots, x=x.imputed, outer.ok=TRUE)

  #calculate means of basis functions for each real subject
  basis.mean <- as.matrix(aggregate(p.spline.basis.values, by=list(subject.id=subject.id), mean)[,-1])

  #transform basis means to use in penalized regression
  constraint.matrix <- matrix(colMeans(basis.mean), nrow=1, ncol=ncol(basis.mean))
  qr.constraint <- qr(t(constraint.matrix))
  transform.matrix <- qr.Q(qr.constraint, complete=TRUE)[,(nrow(constraint.matrix)+1):ncol(constraint.matrix)]
  transformed.basis <- basis.mean %*% transform.matrix

  #compute penalty matrix
  second.order.difference <- diff(diag(ncol(p.spline.basis.values)), differences=2)
  transformed.difference <- second.order.difference %*% transform.matrix
  penalty.matrix <- t(transformed.difference) %*% transformed.difference

  #run penalized regression
  model.data <- data.frame(Y=y.observed, as.data.frame(transformed.basis))
  fitting.type <- match.arg(method)
  pspline.model <- gam(Y ~ transformed.basis, data=model.data, paraPen=list(transformed.basis=list(penalty.matrix)), method=fitting.type, family=binomial(link="logit"))

  #predicted Y
  y.predicted <- lapply(x.to.predict, function(x.values) {

    predicted.basis <- predict_spline_basis(knots=knots, x=x.values)
    predicted.transformed.basis <- predicted.basis %*% transform.matrix

    predicted.values <- predict(pspline.model, newdata=list(transformed.basis=predicted.transformed.basis), type="link")

    return(predicted.values)
  })

  return(y.predicted)
}

#3. 2nd degree fractional polynomial
predict_fractional_polynomial <- function(x.imputed,
                                          subject.id,
                                          y.observed,
                                          x.to.predict) {
  
  #create power terms for fractional polynomial
  exponents <- c(-2, -1, -0.5, 0, 0.5, 1, 2, 3)
  power.terms <- vapply(exponents, function(exponent) if(exponent != 0) x.imputed^exponent else log(x.imputed), numeric(length(x.imputed)))
  colnames(power.terms) <- c("tminus2", "tminus1", "tminushalf", "tzero", "tplushalf", "tplus1", "tplus2", "tplus3")
  
  #create log*power terms for fractional polynomial
  log.terms <- power.terms*log(x.imputed)
  colnames(log.terms) <- colnames(power.terms) %,% "log"
  
  #create data frame of power terms, log*power terms, and y-values averaged over 250 "pseudo-subjects" for each real subject
  all.terms <- data.frame(power.terms, log.terms)
  mean.terms <- aggregate(all.terms, by=list(subject.id=subject.id), mean)
  model.data <- data.frame(mean.terms, Y=y.observed)
  
  #create list of 2nd-degree fractional polynomial combinations
  different.term.models <- combn(colnames(power.terms), 2, simplify=FALSE)
  repeated.term.models <- lapply(1:8, function(term) c(colnames(power.terms)[term], colnames(log.terms)[term]))
  all.fp.combinations <- c(different.term.models, repeated.term.models)
  
  #Run logistic regressions with all possible fractional polynomial models
  fp.formulas <- lapply(all.fp.combinations, function(combination) as.formula("Y ~ " %,% paste(combination, collapse=" + ")))
  fp.models <- lapply(fp.formulas, function(form) glm(formula=form, data=model.data, family=binomial(link="logit")))
  
  #Choose the best fractional polynomial model via minimum AIC
  aic <- vapply(fp.models, AIC, numeric(1))
  best.model <- fp.models[[which.min(aic)]]
  
  #predict Y values using best fractional polynomial model
  y.predicted <- lapply(x.to.predict, function(x.values) {

    power.terms.to.predict <- vapply(exponents, function(exponent) if(exponent != 0) x.values^exponent else log(x.values), numeric(length(x.values)))
    colnames(power.terms.to.predict) <- c("tminus2", "tminus1", "tminushalf", "tzero", "tplushalf", "tplus1", "tplus2", "tplus3")
    log.terms.to.predict <- power.terms.to.predict*log(x.values)
    colnames(log.terms.to.predict) <- colnames(power.terms) %,% "log"
    prediction.data <- data.frame(power.terms.to.predict, log.terms.to.predict)
    
    predicted.values <- predict(best.model, newdata=prediction.data, type="link")
    
    return(predicted.values)
  })
  
  return(y.predicted)
}
