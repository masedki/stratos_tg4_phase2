setwd("~/codes/stratos_tg2_4/datasets_phase2/")
rm(list=ls())
require(knitr)
source("tg24_sim7.R")
set.seed(11)
###  Dataset 1:
# nsim= 200000
# distind = 1    
# mux, sigx = 3.3, 0.25
# f = tg24.f1
tg24.f1 <- function(x){-2.202 + 268*exp(-0.383*x) + 0.00197*exp(0.139*x)}
# nstudy = 15000 or 30000
# vratio = 0.5 or 1.0
# errdist = 0 or 1    
# nrep = 250 or 750
# filename1 = text name of output file with main data 
# filename2 = text name of output file with validation data
# filename3 = text name of output file for Aris
params_grid_1 = expand.grid(nsim = 200000,
                            distind = 1,
                            mux = 3.3,
                            sigx = 0.25,
                            nstudy = c(15000, 30000),
                            vratio = c(0.5, 1.0),
                            errdist = c(0, 1),    
                            nrep = c(250, 750))

params_grid_1 = params_grid_1[-which(params_grid_1$nstudy==15000 & params_grid_1$vratio==0.5 & params_grid_1$errdist==0 & params_grid_1$nrep==250),]
dim(params_grid_1)
for(i in 1:nrow(params_grid_1))
  tg24.sim7(nsim = params_grid_1$nsim[i],
            distind = params_grid_1$distind[i] ,
            mux = params_grid_1$mux[i] ,
            sigx = params_grid_1$sigx[i],
            f = tg24.f1, 
            nstudy = params_grid_1$nstudy[i],
            vratio = params_grid_1$vratio[i],
            errdist = params_grid_1$errdist[i],
            nrep = params_grid_1$nrep[i],
            filename1 = paste("dataset1/part_1/comb_",i,sep=""),
            filename2 = paste("dataset1/part_2/comb_",i,sep=""),
            filename3 = paste("dataset1/part_3/comb_",i,sep=""))
rownames(params_grid_1) = paste("comb_", 1:15, sep="")
kable(params_grid_1, format = "markdown")
### Dataset 2:
# nsim= 10000000 (note this is a larger number than for dataset 1, due to the low prevalence of disease in this example)
# distind = 0    
# mux, sigx = 3.29, 0.24
# f = tg24.f2
tg24.f2 <- function(x){-5.78 + 0.545*x}
# nstudy = 15000 or 30000
# vratio = 0.5 or 1.0
# errdist = 0 or 1    
# nrep = 250 or 750
# filename1 = text name of output file with main data 
# filename2 = text name of output file with validation data
# filename3 = text name of output file for Aris
params_grid_2 = expand.grid(nsim = 10000000,
                            distind = 0,
                            mux = 3.29,
                            sigx = 0.24,
                            nstudy = c(15000, 30000),
                            vratio = c(0.5, 1.0),
                            errdist = c(0, 1),    
                            nrep = c(250, 750))

params_grid_2 = params_grid_2[-which(params_grid_2$nstudy==15000 & params_grid_2$vratio==0.5 & params_grid_2$errdist==0 & params_grid_2$nrep==250),]
dim(params_grid_2)
for(i in 1:nrow(params_grid_2))
  tg24.sim7(nsim = params_grid_2$nsim[i],
            distind = params_grid_2$distind[i] ,
            mux = params_grid_2$mux[i] ,
            sigx = params_grid_2$sigx[i],
            f = tg24.f2, 
            nstudy = params_grid_2$nstudy[i],
            vratio = params_grid_2$vratio[i],
            errdist = params_grid_2$errdist[i],
            nrep = params_grid_2$nrep[i],
            filename1 = paste("dataset2/part_1/comb_",i,sep=""),
            filename2 = paste("dataset2/part_2/comb_",i,sep=""),
            filename3 = paste("dataset2/part_3/comb_",i,sep=""))
rownames(params_grid_2) = paste("comb_", 1:15, sep="")
kable(params_grid_2, format = "markdown")
### Dataset 3:
# nsim= 200000 
# distind = 0    
# mux, sigx = 100, 19.4
# f = tg24.f3
tg24.f3 <- function(x){-2.2 + 0.0135*ifelse(x<90,0,x-90)}
# nstudy = 15000 or 30000
# vratio = 0.5 or 1.0
# errdist = 0 or 1    
# nrep = 250 or 750
# filename1 = text name of output file with main data 
# filename2 = text name of output file with validation data
# filename3 = text name of output file for Aris
params_grid_3 = expand.grid(nsim = 200000,
                            distind = 0,
                            mux = 100,
                            sigx = 19.4,
                            nstudy = c(15000, 30000),
                            vratio = c(0.5, 1.0),
                            errdist = c(0, 1),    
                            nrep = c(250, 750))

params_grid_3 = params_grid_3[-which(params_grid_3$nstudy==15000 & params_grid_3$vratio==0.5 & params_grid_3$errdist==0 & params_grid_3$nrep==250),]
dim(params_grid_3)
for(i in 1:nrow(params_grid_3))
  tg24.sim7(nsim = params_grid_3$nsim[i],
            distind = params_grid_3$distind[i] ,
            mux = params_grid_3$mux[i] ,
            sigx = params_grid_3$sigx[i],
            f = tg24.f3, 
            nstudy = params_grid_3$nstudy[i],
            vratio = params_grid_3$vratio[i],
            errdist = params_grid_3$errdist[i],
            nrep = params_grid_3$nrep[i],
            filename1 = paste("dataset3/part_1/comb_",i,sep=""),
            filename2 = paste("dataset3/part_2/comb_",i,sep=""),
            filename3 = paste("dataset3/part_3/comb_",i,sep=""))
rownames(params_grid_3) = paste("comb_", 1:15, sep="")
kable(params_grid_3, format = "markdown")
### Dataset 4:
# nsim= 200000 
# distind = 1    
# mux, sigx = 4.5, 0.23
# f = tg24.f4
tg24.f4 <- function(x){-3.2 + exp(0.02*ifelse(x<120,0,x-120))}
# nstudy = 15000 or 30000
# vratio = 0.5 or 1.0
# errdist = 0 or 1    
# nrep = 250 or 750
# filename1 = text name of output file with main data 
# filename2 = text name of output file with validation data
# filename3 = text name of output file for Aris
params_grid_4 = expand.grid(nsim = 200000,
                            distind = 1,
                            mux = 4.5,
                            sigx = 0.23,
                            nstudy = c(15000, 30000),
                            vratio = c(0.5, 1.0),
                            errdist = c(0, 1),    
                            nrep = c(250, 750))
params_grid_4 = params_grid_4[-which(params_grid_4$nstudy==15000 & params_grid_4$vratio==0.5 & params_grid_4$errdist==0 & params_grid_4$nrep==250),]
dim(params_grid_4)
for(i in 1:nrow(params_grid_4))
  tg24.sim7(nsim = params_grid_4$nsim[i],
            distind = params_grid_4$distind[i] ,
            mux = params_grid_4$mux[i] ,
            sigx = params_grid_4$sigx[i],
            f = tg24.f4, 
            nstudy = params_grid_4$nstudy[i],
            vratio = params_grid_4$vratio[i],
            errdist = params_grid_4$errdist[i],
            nrep = params_grid_4$nrep[i],
            filename1 = paste("dataset4/part_1/comb_",i,sep=""),
            filename2 = paste("dataset4/part_2/comb_",i,sep=""),
            filename3 = paste("dataset4/part_3/comb_",i,sep=""))
rownames(params_grid_4) = paste("comb_", 1:15, sep="")
kable(params_grid_4, format = "markdown")
### Dataset 5:
# nsim= 200000 
# distind = 2    
# mux, sigx = 30, 80
# f = tg24.f5
tg24.f5 <- function(x){log((3/7)*x^6 + (1/19)*50^6)-log(50^6+x^6)}
# nstudy = 15000 or 30000
# vratio = 0.5 or 1.0
# errdist = 0 or 1    
# nrep = 250 or 750
# filename1 = text name of output file with main data 
# filename2 = text name of output file with validation data
# filename3 = text name of output file for Aris
params_grid_5 = expand.grid(nsim = 200000,
                            distind = 2,
                            mux = 30,
                            sigx = 80,
                            nstudy = c(15000, 30000),
                            vratio = c(0.5, 1.0),
                            errdist = c(0, 1),    
                            nrep = c(250, 750))

params_grid_5 = params_grid_5[-which(params_grid_5$nstudy==15000 & params_grid_5$vratio==0.5 & params_grid_5$errdist==0 & params_grid_5$nrep==250),]
dim(params_grid_5)
for(i in 1:nrow(params_grid_5))
  tg24.sim7(nsim = params_grid_5$nsim[i],
            distind = params_grid_5$distind[i] ,
            mux = params_grid_5$mux[i] ,
            sigx = params_grid_5$sigx[i],
            f = tg24.f5, 
            nstudy = params_grid_5$nstudy[i],
            vratio = params_grid_5$vratio[i],
            errdist = params_grid_5$errdist[i],
            nrep = params_grid_5$nrep[i],
            filename1 = paste("dataset5/part_1/comb_",i,sep=""),
            filename2 = paste("dataset5/part_2/comb_",i,sep=""),
            filename3 = paste("dataset5/part_3/comb_",i,sep=""))

rownames(params_grid_5) = paste("comb_", 1:15, sep="")
kable(params_grid_5, format = "markdown")
