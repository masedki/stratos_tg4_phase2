rm(list=ls())
require(parallel)
setwd("~/codes/stratos_tg2_4/STRATOS_smooth_ME/")


source("skwn_fp_function.R")



X = as.list(data.frame(t(expand.grid(1:5, 1:15))))
mclapply(X, 
         skwn_fp_run, 
         mc.preschedule = TRUE, 
         mc.set.seed = TRUE, 
         mc.silent = FALSE, 
         mc.cores = 75, 
         mc.cleanup = TRUE, 
         mc.allow.recursive = TRUE)

## run the missing one 
## check the number of cores in skwn_fp_function :
## run the failed test 
skwn_fp_run(c(5,1))
