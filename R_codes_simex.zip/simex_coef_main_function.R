#############################################################################
######        THIS CODE CONTAINS A FUNCTION THAT EXECUTES SIMEX        ######
######              ON COEFFICIENTS RATHER THAN POINTWISE              ######
######                    AS A SENSITIVITY ANALYSIS                    ######
######                                                                 ######
######     THIS CODE IS SPECIFIC TO DATASETS 1-5 PROVIDED IN THE       ######
######  PRELIMINARY ANALYSIS PHASE OF THE SIMEX TG2-TG4 COLLABORATION  ######
#############################################################################

##################################################
######  CREATED BY: STEVE FERREIRA GUERRA   ######
######     LAST MODIFIED: NOV 11, 2023      ######
##################################################

simex_coef_run = function(p){
  dataset = p[1]
  comb = p[2]
  #Relative Paths for source files
  data.directory   <- "../datasets_phase2/"
  output.directory <- "./results_simex_coef/"
  
  #Load seeds for random error generating
  seeds = read.table("seeds")
  dataset_main <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 1 %,% "/comb_" %,% comb, header=TRUE, sep="")
  dataset_val <- read.table(data.directory %,% "dataset" %,% dataset %,% "/part_" %,% 2 %,% "/comb_" %,% comb, header=TRUE, sep="")
  
  
  
  n = dim(dataset_main)[1]
  #x-values for reporting
  if (dataset==1) {x.pred <- seq(from=10,to=50,by=0.2)}
  if (dataset==2) {x.pred <- seq(from=2.6, to=4, by=0.007)}
  if (dataset==3) {x.pred <- seq(from=45, to=155, by=0.55)}
  if (dataset==4) {x.pred <- seq(from=40, to=160, by=0.6)}
  if (dataset==5) {x.pred <- seq(from=18, to=92, by=0.37)}
  
  #Obtaining an estimate of sd of ME from the validation data
  sd_ME <- sqrt(var(dataset_val$xrep1 - dataset_val$xrep2)/2)
  
  ### SIMEX ALGORITHM ###
  
  #Objects to store final SIMEX-corrected values
  SIMEX.coef_reg.bs = c()
  SIMEX.coef_fp = c()
  
  #Increments for increase of ME
  lambda = seq(0.2,2,0.2)
  #Number of SIMEX repetitions
  B = 25
  
  coef_reg.bs_mean <- matrix(NA, nrow = length(lambda), ncol = 5)
  coef_fp_mean <- matrix(NA, nrow = length(lambda), ncol = 3)
  
  #Storing the FP functions
  coef_reg.bs_mean[1,] <- coef(glm(dataset_main$ysel ~ bs(dataset_main$xselobs1 , degree=3, knots = c(median(dataset_main$xselobs1)), Boundary.knots = range(dataset_main$xselobs1)), family = "binomial"))
  #Shifting X.star for FPs to ensure positivity
  X.star_FP <- dataset_main$xselobs1 + 7*sd_ME
  fp.1 <- mfp(dataset_main$ysel ~ fp(X.star_FP, select = 1, alpha = 1), family = "binomial")
  coef_fp_mean[1,] <- coef(fp.1)
  
  for (j in c(2:length(lambda))) {
    
    coef_reg.bs <- matrix(NA, nrow = B, ncol = 5)
    coef_fp <- matrix(NA, nrow = B, ncol = 3)
    
    for (b in c(1:B)) {
      set.seed(seeds[b,1])
      
      error_SIMEX <- rnorm(n,0,sd_ME)
      X.star.star <- dataset_main$xselobs1 + sqrt(lambda[j])*error_SIMEX
      X.star.star_FP <- X.star_FP + sqrt(lambda[j])*error_SIMEX
      
      coef_reg.bs[b,] <- coef(glm(dataset_main$ysel ~ bs(X.star.star, degree=3, knots = c(median(dataset_main$xselobs1)), Boundary.knots = range(dataset_main$xselobs1)), family = "binomial"))
      
      #Different models depending on whether log() is used as a function by FP
      if(fp.1$powers[1] != fp.1$powers[2]){
        if(fp.1$powers[1] == 0){
          coef_fp[b,] <- coef(glm(dataset_main$ysel ~ I(log(X.star.star_FP)) + I(X.star.star_FP^c(fp.1$powers)[2]), family = "binomial"))
        } else if (fp.1$powers[2] == 0){
          coef_fp[b,] <- coef(glm(dataset_main$ysel ~ I(X.star.star_FP^c(fp.1$powers)[1]) + I(log(X.star.star_FP)), family = "binomial"))
        } else {
          coef_fp[b,] <- coef(glm(dataset_main$ysel ~ I(X.star.star_FP^c(fp.1$powers)[1]) + I(X.star.star_FP^c(fp.1$powers)[2]), family = "binomial"))
        }
      } else if (fp.1$powers[1] == 0 & fp.1$powers[2] == 0){
        coef_fp[b,] <- coef(glm(dataset_main$ysel ~ I(log(X.star.star_FP)) + I(log(X.star.star_FP)*log(X.star.star_FP)), family = "binomial"))
      } else {
        coef_fp[b,] <- coef(glm(dataset_main$ysel ~ I(X.star.star_FP^c(fp.1$powers)[1]) + I(X.star.star_FP^c(fp.1$powers)[2]*log(X.star.star_FP)), family = "binomial"))
      }
    }
    coef_reg.bs_mean[j,] <- colMeans(coef_reg.bs)
    coef_fp_mean[j,] <- colMeans(coef_fp)
  }
  
  #### EXTRAPOLATION PHASE ####
  for (k in c(1:5)){
    SIMEX.coef_reg.bs[k] <- coef(lm(coef_reg.bs_mean[,k] ~ lambda + I(lambda^2)))%*%c(1,-1,1)
  }
  
  for (k in 1:3) {
    
    SIMEX.coef_fp[k] <- coef(lm(coef_fp_mean[,k] ~ lambda + I(lambda^2)))%*%c(1,-1,1)
    
  }
  
  
  
  #Outputs two tables for each dataset, where each table contains, the name of the method and the number of the initial dataset
  reg.bs.out <- bs(x.pred, degree=3, knots = c(median(dataset_main$xselobs1)), Boundary.knots = range(dataset_main$xselobs1))%*% SIMEX.coef_reg.bs[2:5] + SIMEX.coef_reg.bs[1]
  
  x.pred_FP <- x.pred + 7*sd_ME
  if(fp.1$powers[1] != fp.1$powers[2]){
    if(fp.1$powers[1] == 0){
      fp.out <- cbind(rep(1,length(x.pred_FP)),log(x.pred_FP),x.pred_FP^c(fp.1$powers)[2])%*%SIMEX.coef_fp
    } else if (fp.1$powers[2] == 0){
      fp.out <- cbind(rep(1,length(x.pred_FP)),x.pred_FP^c(fp.1$powers)[1],log(x.pred_FP))%*%SIMEX.coef_fp
    } else {
      fp.out <- cbind(rep(1,length(x.pred_FP)),x.pred_FP^c(fp.1$powers)[1],x.pred_FP^c(fp.1$powers)[2])%*%SIMEX.coef_fp
    }
  } else if (fp.1$powers[1] == 0 & fp.1$powers[2] == 0){
    fp.out <- cbind(rep(1,length(x.pred_FP)),log(x.pred_FP),log(x.pred_FP)*log(x.pred_FP))%*%SIMEX.coef_fp
  } else {
    fp.out <- cbind(rep(1,length(x.pred_FP)),x.pred_FP^c(fp.1$powers)[1],(x.pred_FP^c(fp.1$powers)[2])*log(x.pred_FP))%*%SIMEX.coef_fp
  }
  
  regbs_SIMEX = data.frame(x=x.pred, fx=reg.bs.out)
  fp_SIMEX = data.frame(x = x.pred, fx=fp.out)
  
  save(regbs_SIMEX, fp_SIMEX, file =  output.directory %,% "res_dataset" %,%  dataset %,% "/res_" %,% "comb_" %,%  comb %,% ".rda")
  gc()
}
