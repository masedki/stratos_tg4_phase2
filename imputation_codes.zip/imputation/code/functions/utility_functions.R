# Name: Amer Moosa
# File location: //omni/btp/dcp/analysis/dcpitis/simulations/STRATOS_Competition/main_script/utils/utility_functions.R
# Date Started: 10/5/2023
# 
# Program Purpose:
# Helper functions for STRATOS competition workflow
# - Run regression calibration and multiple imputation on dataset
# - Combine main and val datasets into a single dataset for analysis

#Function that runs predictions with a main and val dataset
run_predictions <- function(main, val, x.to.predict) {
  
  #create combined dataset for analysis
  analysis.data <- make_analysis_dataset(main.data=main, 
                                         val.data=val)
  
  #regression calibration predictions
  print("Regression Calibration")
  regression.calibration <- regression_calibration(analysis.data=analysis.data,
                                                   x.to.predict=x.to.predict)

  #multiple imputation predictions (10 imputations)
  print("Multiple Imputation")
  multiple.imputation <- multiple_imputation(analysis.data=analysis.data,
                                             x.to.predict=x.to.predict,
                                             num.imputations=10)
  
  #output regression calibration and multiple imputation data
  prediction.output <- list(regression.calibration=regression.calibration,
                            multiple.imputation=multiple.imputation)
  
  return(prediction.output)
}

#Combine main and val datasets into a single dataset for analysis
make_analysis_dataset <- function(main.data,
                                  val.data) {
  
  #merge Y values from main data into val data
  val.with.y <- merge(val.data, main.data[,c("X", "ysel")], by.x="index2", by.y="X")
  
  #variable names for each recall
  recall.variable.names <- c("subject.id", "X", "Y")
  
  #create first recall from main data
  first.recall <- setNames(main.data[,c("X", "xselobs1", "ysel")], recall.variable.names)
  
  #create second recall from val data
  second.recall <- setNames(val.with.y[,c("index2", "xrep2", "ysel")], recall.variable.names)
  
  #combine recalls
  all.recalls <- rbind(first.recall, second.recall)
  
  #add recall number and intercept term to combined recall data
  recall.num <- rep(c(1,2), times=c(nrow(first.recall), nrow(second.recall)))
  analysis.data <- data.frame(all.recalls, recall=recall.num, intercept=1)
  
  #output analysis data
  return(analysis.data)
}

#Box-Cox transformation
boxcox_transform <- function(x, lambda) {
  
  if(lambda == 0) {
    
    bc.x <- log(x)
  } else {
    
    bc.x <- (x^lambda - 1)/lambda
  }
  
  return(bc.x)
}
