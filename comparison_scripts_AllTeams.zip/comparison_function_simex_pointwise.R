rm(list=ls())
require(readr)
setwd("~/codes/stratos_tg2_4/phase2_run/")
output_folder <- "./results_simex_pointwise/"
`%,%` <- function(x,y) paste0(x,y)

for(dataset in 1:5)
  for(comb in 1:15)
  {
    load(output_folder %,% "/res_dataset" %,% dataset %,% "/res_comb_" %,% comb %,% ".rda", res_dataset <- new.env())
    colnames(res_dataset$pspli_SIMEX) = colnames(res_dataset$fp_SIMEX) = colnames(res_dataset$regbs_SIMEX) = c("x.value", "prediction") 
    
    x.step = 1:length(res_dataset$fp_SIMEX$x.value)
    x = res_dataset$fp_SIMEX$x.value
    
    esty_regbs_simex = res_dataset$regbs_SIMEX$prediction
    esty_pspli_simex = res_dataset$pspli_SIMEX$prediction
    esty_fp_simex = res_dataset$fp_SIMEX$prediction
    
    
    
    
    #The functions log(P(Y=1|x)) = f(x) used for generating the data
    tg24.f1 <- function(x){-2.202 + 268*exp(-0.383*x) + 0.00197*exp(0.139*x)}
    tg24.f2 <- function(x){-5.78 + 0.545*x}
    tg24.f3 <- function(x){  -2.2 + 0.0135*ifelse(x<90,0,x-90)}
    tg24.f4 <- function(x){  -3.2 + exp(0.02*ifelse(x<120,0,x-120))}
    tg24.f5 <- function(x){log((3/7)*x^6 + (1/19)*50^6)-log(50^6+x^6)}
    
    
    # The distributions of X in the population
    tg24.dist1 <- function(x){dlnorm(x,3.3,0.25)}
    tg24.dist2 <- function(x){dnorm(x,3.29,0.24)}
    tg24.dist3 <- function(x){dnorm(x,100,19.4)}
    tg24.dist4 <- function(x){dlnorm(x,4.5,0.23)}
    tg24.dist5 <- function(x){dunif(x,30,80)}
    
    
    #  Correction for our nested case control design (4 controls to every case):
    # The integrand functions below are P(Y=1|x)*h(x), where h(x) is the population  distribution of X.
    
    tg24.integrand1 <- function(x){
      exp(tg24.f1(x))*tg24.dist1(x)/(1+exp(tg24.f1(x)))}
    tg24.integrand2 <- function(x){
      exp(tg24.f2(x))*tg24.dist2(x)/(1+exp(tg24.f2(x)))}
    tg24.integrand3 <- function(x){
      exp(tg24.f3(x))*tg24.dist3(x)/(1+exp(tg24.f3(x)))}
    tg24.integrand4 <- function(x){
      exp(tg24.f4(x))*tg24.dist4(x)/(1+exp(tg24.f4(x)))}
    tg24.integrand5 <- function(x){
      exp(tg24.f5(x))*tg24.dist5(x)/(1+exp(tg24.f5(x)))}
    
    #  The integrals below are the computed value of P(Y=1) in the population
    integrate(tg24.integrand1,4,85)
    #0.127647 with absolute error < 5e-05
    integrate(tg24.integrand2,0,10)
    #0.01836609 with absolute error < 1.4e-08
    integrate(tg24.integrand3,20,180)
    #0.1192627 with absolute error < 8e-06
    integrate(tg24.integrand4,0,400)
    #0.1051961 with absolute error < 7.4e-05
    integrate(tg24.integrand5,20,100)
    #0.2033248 with absolute error < 2.2e-15
    
    p1 <- 0.127647
    p2 <- 0.01836609
    p3 <- 0.1192627
    p4 <- 0.1051961
    p5 <- 0.2033248
    
    
    
    
    if(dataset == 1)
    {
      y = tg24.f1(x) + log(.25*(1-p1)/p1)
      tg24.qlow<-qlnorm(0.025,3.3,0.25)
      tg24.qhi<-qlnorm(0.975,3.3,0.25)
      tg24.seqlow = x.step[x-tg24.qlow==min(x[x>=tg24.qlow]-tg24.qlow)]
      tg24.seqhi = x.step[x-tg24.qhi==max(x[x<=tg24.qhi]-tg24.qhi)]
      x.low = x[tg24.seqlow]
      x.hi = x[tg24.seqhi]
    }
    if(dataset == 2) 
    {
      y = tg24.f2(x) + log(.25*(1-p2)/p2)
      tg24.qlow = qnorm(0.025,3.29,0.24)
      tg24.qhi  = qnorm(0.975,3.29,0.24)
      tg24.seqlow = x.step[x-tg24.qlow==min(x[x>=tg24.qlow]-tg24.qlow)]
      tg24.seqhi =  x.step[x-tg24.qhi==max(x[x<=tg24.qhi]-tg24.qhi)]
      x.low = x[tg24.seqlow]
      x.hi = x[tg24.seqhi]
      
    }
    if(dataset == 3)
    {
      y = tg24.f3(x) + log(.25*(1-p3)/p3)
      tg24.qlow  = qnorm(0.025,100,19.4)
      tg24.qhi   = qnorm(0.975,100,19.4)
      tg24.seqlow = x.step[x-tg24.qlow==min(x[x>=tg24.qlow]-tg24.qlow)]
      tg24.seqhi = x.step[x-tg24.qhi==max(x[x<=tg24.qhi]-tg24.qhi)]
      x.low = x[tg24.seqlow]
      x.hi = x[tg24.seqhi]
      
    }
    if(dataset == 4) 
    {
      y = tg24.f4(x) + log(.25*(1-p4)/p4)
      tg24.qlow  = qlnorm(0.025,4.5,0.23)
      tg24.qhi = qlnorm(0.975,4.5,0.23)
      tg24.seqlow = x.step[x-tg24.qlow==min(x[x>=tg24.qlow]-tg24.qlow)]
      tg24.seqhi =  x.step[x-tg24.qhi==max(x[x<=tg24.qhi]-tg24.qhi)]
      x.low = x[tg24.seqlow]
      x.hi = x[tg24.seqhi]
      
    }
    if(dataset == 5) 
    {
      y = tg24.f5(x) + log(.25*(1-p5)/p5)
      tg24.qlow  = qunif(0.025,30,80)
      tg24.qhi = qunif(0.975,30,80)
      tg24.seqlow = x.step[x-tg24.qlow==min(x[x>=tg24.qlow]-tg24.qlow)]
      tg24.seqhi =  x.step[x-tg24.qhi==max(x[x<=tg24.qhi]-tg24.qhi)]
      x.low = x[tg24.seqlow]
      x.hi = x[tg24.seqhi]
    }
    
    # y = scaler(y, a, b)
    # esty_regbs_simex = scaler(esty_regbs_simex, a, b)
    # esty_pspli_simex = scaler(esty_pspli_simex, a, b)
    # esty_fp_simex = scaler(esty_fp_simex, a, b)
    pdf(file = output_folder %,% "/res_dataset" %,% dataset %,% "_figures/" %,% "check_plot_comb_" %,% comb %,%".pdf")
    plot(x, 
         y, 
         lwd=3, 
         xlab="X" %,% dataset, 
         ylab="Y" %,% dataset,'l', 
         main= "SIMEX_Pointwise_" %,% dataset %,% "_comb_" %,% comb,
         ylim= c(-3, 2))
    
    
    lines(x, esty_regbs_simex, col=2,lwd=3)
    lines(x, esty_pspli_simex, col=3,lwd=3)
    lines(x, esty_fp_simex, col=4,lwd=3)
    abline(v=x.low, col=5, lwd=2)
    abline(v=x.hi, col=6, lwd=2)
    legend("topright", c("real", "simex_pointwise_bs", "simex_pointwise_pspli", "simex_pointwise_fp", "x.low", "x.hi"),col=1:6, lty=1, lwd=2)
    dev.off()
  }