skwn_bspline_run = function(p){
  
  dataset = p[1]
  comb = p[2]
  print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... start ... ", sep=""))
  datapath = "~/codes/stratos_tg2_4/datasets_phase2/dataset"
  resultpath = "~/codes/stratos_tg2_4/STRATOS_smooth_ME/results_skwn_bspline"
  dt.mn <- read.delim(paste(datapath, dataset,"/part_1/comb_", comb,sep=""), header=T, sep="")
  names(dt.mn)[[1]] <- "index"
  dt.rp <- read.delim(paste(datapath, dataset,"/part_2/comb_", comb,sep=""), header=T, sep="")
  ## Some reshaping
  xstr.main <- dt.mn[,"xselobs1"][-dt.rp[,"index2"]]
  xstr.rep1 <- dt.rp[,"xrep1"]
  xstr.rep2 <- dt.rp[,"xrep2"]
  y.main <- dt.mn[,"ysel"][-dt.rp[,"index2"]]
  y.rep <- dt.mn[,"ysel"][dt.rp[,"index2"]]
  
  ## Preparation to call Stan
  knt <- quantile(xstr.main,c(.1,.3,.5,.7,.9))
  
  ### Stan model parameterized as (f(knt))
  M <- solve(cbind(1,knt,knt^2,knt^3, pmax(knt-knt[3],0)^3))
  
  ### basis is cubic splines with one knot at knt[3]=median(xstr.main)
  mcmc.inputs <- list(n_main=length(xstr.main), n_rep=length(y.rep), knt=knt, M=M, 
                      xstr_main=xstr.main, xstr_rep1=xstr.rep1, xstr_rep2=xstr.rep2, 
                      y_main=y.main, y_rep=y.rep)
  
  
  
  ## Work up four "in the-ballpark" initial values for MCMC:
  y.hat <- mean(c(y.main,y.rep))
  tau.hat <- sqrt(var(xstr.rep1-xstr.rep2)/2)
  mu.hat <- mean(xstr.main)
  sig.hat <- sqrt(var(xstr.main)-tau.hat^2)
  xmain.hat <- (xstr.main/tau.hat^2 + mu.hat/sig.hat^2)/(1/tau.hat^2+1/sig.hat^2)
  xrep.hat <-  ((xstr.rep1+xstr.rep2)/tau.hat^2 + mu.hat/sig.hat^2)/(2/tau.hat^2+1/sig.hat^2)
  
  logit <- function(p) {log(p)-log(1-p)}
  
  sval1=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(5, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## same as sval1, but fresh randomize
  sval2=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(5, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## fresh randomize
  sval3=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(5, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  ## fresh randomize
  sval4=list(mu=mu.hat, sig=sig.hat, tau=tau.hat, shp_x=0,shp_xstr=0,
             fval=rnorm(5, mean=logit(y.hat), sd=sqrt(1/(1000*y.hat*(1-y.hat)))),
             x_main=rnorm(length(xmain.hat), xmain.hat, sqrt(1/(1/sig.hat^2+1/tau.hat^2))),
             x_rep=rnorm(length(xrep.hat), xrep.hat, sqrt(1/(1/sig.hat^2+2/tau.hat^2))))
  
  
  
  ## Re-run the MCMC or load saved output?
  REDO <- T
  flnm <- paste(resultpath, "/res_dataset",dataset, "/res_comb_",comb,".rda",sep="")
  require(rstan)
  rstan_options(auto_write = TRUE)
  
  
  ## Call Stan (or load previous MCMC output)
  if (REDO) {
    st.tm <- Sys.time()  
    
    fit <- stan(file = 'code-review-skwn-bspline.stan', 
                pars=c("mu","sig","tau","fval","shp_x","shp_xstr", "x_main_head","x_rep_head"),
                data = mcmc.inputs, chains=4, 
                init=list(sval1,sval2,sval3,sval4), 
                warmup=250, iter=2750, thin=1,cores=1)
    
    lpsd.tm <- Sys.time()-st.tm
    print(paste("dataset : ... ", dataset, " ... comb : ... ", comb, "  ... ok ... ", sep=""))
    save(fit, file=flnm)
  }
}